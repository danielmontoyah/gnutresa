<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.regiones.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['Regio_Municipio'] = 'Municipios';
$app_list_strings['moduleList']['Regio_Departamentos'] = 'Departamentos';
$app_list_strings['moduleList']['Regio_Barrios'] = 'Barrios';
$app_list_strings['moduleListSingular']['Regio_Municipio'] = 'Municipio';
$app_list_strings['moduleListSingular']['Regio_Departamentos'] = 'Departamento';
$app_list_strings['moduleListSingular']['Regio_Barrios'] = 'Barrio';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_activctrlcumplimiento_c_list.php

 // created: 2016-12-01 00:35:40

$app_list_strings['sasa_activctrlcumplimiento_c_list']=array (
  'Si' => 'Si',
  'No' => 'No',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_unmarkctrlcumplimient_c_list.php

 // created: 2016-12-01 00:53:59

$app_list_strings['sasa_unmarkctrlcumplimient_c_list']=array (
  'Si' => 'Si',
  'No' => 'No',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_case_type_dom.php

 // created: 2016-12-20 17:55:30

$app_list_strings['case_type_dom']=array (
  '' => '',
  'Administration' => 'Administración',
  'Product' => 'Producto',
  'User' => 'Usuario',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_regional_list.php

 // created: 2016-10-19 02:21:36

$app_list_strings['sasa_regional_list']=array (
  '' => '',
  'Medellin' => 'Medellín',
  'Bogota' => 'Bogotá',
  'Cali' => 'Cali',
  'Barranquilla' => 'Barranquilla',
  'Pereira' => 'Pereira',
  'No_Aplica' => 'No Aplica',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_pregunta3_list.php

 // created: 2016-09-01 14:19:22

$app_list_strings['sasa_pregunta3_list']=array (
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_genero_c_list.php

 // created: 2016-08-22 21:52:35

$app_list_strings['sasa_genero_c_list']=array (
  '' => '',
  'Femenino' => 'Femenino',
  'Masculino' => 'Masculino',
  'Indeterminado' => 'Indeterminado',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_organizaciondeventas_list.php

 // created: 2016-08-16 15:59:04

$app_list_strings['sasa_organizaciondeventas_list']=array (
  '' => '',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_pais_list.php

 // created: 2016-09-22 22:14:23

$app_list_strings['sasa_pais_list']=array (
  '' => '',
  'Colombia' => 'Colombia',
  'Alemania' => 'Alemania',
  'Antigua y Barbuda' => 'Antigua y Barbuda',
  'Argentina' => 'Argentina',
  'Aruba' => 'Aruba',
  'Australia' => 'Australia',
  'Barbados' => 'Barbados',
  'Bolivia' => 'Bolivia',
  'Brasil' => 'Brasil',
  'Canada' => 'Canadá',
  'China' => 'China',
  'Corea del Norte' => 'Corea del Norte',
  'Corea del Sur' => 'Corea del Sur',
  'Costa Rica ' => 'Costa Rica ',
  'Croacia' => 'Croacia',
  'Cuba' => 'Cuba',
  'Curacao' => 'Curacao',
  'Dominica' => 'Dominica',
  'Ecuador' => 'Ecuador',
  'Estados Unidos' => 'Estados Unidos',
  'El Salvador' => 'El Salvador',
  'Emiratos Arabes' => 'Emiratos Arabes',
  'Espana' => 'España',
  'Estonia' => 'Estonia',
  'Francia' => 'Francia',
  'Guatemala' => 'Guatemala',
  'Guayana' => 'Guayana',
  'Guyana Holandesa' => 'Guyana Holandesa',
  'Haiti' => 'Haití',
  'Honduras' => 'Honduras',
  'Hong Kong' => 'Hong Kong',
  'Italia' => 'Italia',
  'Jamaica' => 'Jamaica',
  'Japon' => 'Japón',
  'Malasia' => 'Malasia',
  'Martinica' => 'Martinica',
  'Mexico' => 'México',
  'Panama' => 'Panamá',
  'Paraguay' => 'Paraguay',
  'Peru' => 'Perú',
  'Polonia' => 'Polonia',
  'Puerto Rico' => 'Puerto Rico',
  'Reino Unido' => 'Reino Unido',
  'Republica Dominicana' => 'República Dominicana',
  'Santa Lucia' => 'Santa Lucía',
  'Singapur' => 'Singapur',
  'Suiza' => 'Suiza',
  'Suriname' => 'Suriname',
  'Trinidad y Tobago' => 'Trinidad y Tobago',
  'Uruguay' => 'Uruguay',
  'Venezuela' => 'Venezuela',
  'Nicaragua' => 'Nicaragua',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.activos.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nuta_activos'] = 'Activos';
$app_list_strings['moduleListSingular']['nuta_activos'] = 'Activo';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.vendedores.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutv_vendedores'] = 'Vendedores';
$app_list_strings['moduleListSingular']['nutv_vendedores'] = 'Vendedor';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sociedad_por_cuenta.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutsc_sociedad_por_cuenta'] = 'Sociedades por Cuenta';
$app_list_strings['moduleListSingular']['nutsc_sociedad_por_cuenta'] = 'Sociedad por cuenta';
$app_list_strings['nut_sociedad_list']['NO'] = 'NO';
$app_list_strings['nut_sociedad_list']['ME'] = 'ME';
$app_list_strings['nut_sociedad_list']['CN'] = 'CN';
$app_list_strings['nut_sociedad_list']['CO'] = 'CO';
$app_list_strings['nut_sociedad_list']['PO'] = 'PO';
$app_list_strings['nut_sociedad_list']['SN'] = 'SN';
$app_list_strings['nut_sociedad_list']['LR'] = 'LR';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_regional_c_list.php

 // created: 2016-08-31 22:34:14

$app_list_strings['sasa_regional_c_list']=array (
  'Barranquilla' => 'Barranquilla',
  'Bogota' => 'Bogotá',
  'Cali' => 'Cali',
  'Eje Cafetero' => 'Eje Cafetero',
  'Medellin' => 'Medellín',
  'Centroamerica' => 'Centroamérica',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sociedad_list.php

 // created: 2016-08-13 19:42:21

$app_list_strings['sociedad_list']=array (
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_kna1_stcdt_list.php

 // created: 2016-08-31 14:43:25

$app_list_strings['sasa_kna1_stcdt_list']=array (
  '00' => 'Otros Documentos',
  '02' => 'Cédula (R.Dominicana)',
  '03' => 'Pasaporte (R.Dominicana)',
  '04' => 'Carnet de Extranjeria',
  '06' => 'RUC',
  '07' => 'Pasaporte',
  '08' => 'RNC (R.Dominicana)',
  '09' => 'DNI (Peru-Ecuador)',
  11 => 'Registro Clivil',
  12 => 'Tarjeta de Identidad',
  13 => 'CC',
  15 => 'Tarjeta de Registro (Salvador)',
  21 => 'Tarjeta de Extranjeria',
  22 => 'Cédula de Extranjeria',
  31 => 'NIT',
  41 => 'Pasaporte',
  42 => 'Tipo de Documento Extranjero',
  43 => 'Doc. para Información Exogena',
  50 => 'RFC-REG',
  55 => 'Con Tax Number',
  56 => 'SSN',
  57 => 'Asignación Interna',
  60 => 'RIF',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipo_nota_list.php

 // created: 2016-09-04 14:46:07

$app_list_strings['sasa_tipo_nota_list']=array (
  '' => '',
  0 => 'Guía',
  1 => 'Factura',
  2 => 'Remisión',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_resultadollamada_c_list.php

 // created: 2016-09-04 13:10:05

$app_list_strings['sasa_resultadollamada_c_list']=array (
  '' => '',
  'Contactado' => 'Contactado',
  'No contactado' => 'No contactado',
  'Reprogramada' => 'Reprogramada',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_sociedad_list.php

 // created: 2016-10-08 00:39:18

$app_list_strings['sasa_sociedad_list']=array (
  '' => '',
  'AGNO' => 'AGNO',
  'ME' => 'ME',
  'CN' => 'CN',
  'CO' => 'CO',
  'PO' => 'PO',
  'SN' => 'SN',
  'LR' => 'LR',
  'AC' => 'AC',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.nuti_interlocutores.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nuti_nuti_interlocutores'] = 'Interlocutores';
$app_list_strings['moduleList']['nuti_Interlocutores'] = 'Interlocutores';
$app_list_strings['moduleListSingular']['nuti_nuti_interlocutores'] = 'Interlocutor';
$app_list_strings['moduleListSingular']['nuti_Interlocutores'] = 'Interlocutor';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_lead_source_list.php

 // created: 2016-09-02 22:49:57

$app_list_strings['lead_source_list']=array (
  '' => '',
  'Llamada Telefonica' => 'Llamada Teléfonica',
  'Correo Electronico' => 'Correo Electrónico',
  'Correspondencia Fisica' => 'Correspondencia Fisica',
  'Visita Personalizada' => 'Visita Personalizada',
  'Mensaje de Texto' => 'Mensaje de Texto',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_operacion_list.php

 // created: 2016-10-05 00:52:33

$app_list_strings['sasa_operacion_list']=array (
  '' => '',
  'Directa' => 'Directa',
  'Indirecta' => 'Indirecta',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sas_consumidorreiterativo_c_list.php

 // created: 2016-09-30 01:18:15

$app_list_strings['sas_consumidorreiterativo_c_list']=array (
  '' => '',
  'Si' => 'Si',
  'No' => 'No',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_detallle_c_list.php

 // created: 2016-09-24 23:52:16

$app_list_strings['sasa_detallle_c_list']=array (
  '' => '',
  0 => 'Abollado',
  1 => 'Actualización de Datos Consumidor',
  2 => 'Agencia de Cobros',
  3 => 'Alistamiento Mal Realizado',
  4 => 'Amenaza Demanda Actividad Promocional',
  5 => 'Amenaza Demanda Compañía',
  6 => 'Amenaza Demanda Producto',
  7 => 'Arrugado',
  8 => 'Asesoría para Usar el Portal',
  9 => 'Asignación de Plan Itinerario',
  10 => 'Asistió',
  11 => 'Autoriza Tratamiento de Datos',
  12 => 'Baboso',
  13 => 'Billeteros',
  14 => 'Bloom',
  15 => 'Calidad del Premio',
  16 => 'Call Center y Otros',
  17 => 'Cambio',
  18 => 'Cambio de Dirección',
  19 => 'Cancelación/Modificación',
  20 => 'Cantidad de Vendedores',
  21 => 'Carro Heladero',
  22 => 'Código',
  23 => 'Color',
  24 => 'Compactado y Aglomerado',
  25 => 'Condición de Pago',
  26 => 'Condiciones para Ser Cliente',
  27 => 'Congelador Falla Funcional',
  28 => 'Congelador Falla No Funcional',
  29 => 'Contacto No Efectivo',
  30 => 'Contrato de Empresaria',
  31 => 'Cristalizado',
  32 => 'Cuchara o Pitillo',
  33 => 'Deforme',
  34 => 'Demora en la Entrega',
  35 => 'Derretido',
  36 => 'Digitado No Facturado',
  37 => 'Disminución de Cantidad en Producto',
  38 => 'Easy Open',
  39 => 'Elemento Promocional',
  40 => 'Empaque Sellado Sin Producto',
  41 => 'En Corrugado, Fardo o Bolsa',
  42 => 'En Unidad de Consumo',
  43 => 'En Unidad de Venta',
  44 => 'Entrega',
  45 => 'Entrega de Premios',
  46 => 'Entrega en Dirección Incorrecta',
  47 => 'Entregador',
  48 => 'Entregador no Entregó el Pedido',
  49 => 'Envio de Referencia Equivocada',
  50 => 'Error en la Toma de Pedido',
  51 => 'Error en la Toma de Pedido Televendedor',
  52 => 'Errores de Marcación',
  53 => 'Esquema de Atención',
  54 => 'Exhibición del Punto de Venta',
  55 => 'Experiencias',
  56 => 'Factura Original no Entregada',
  57 => 'Facturado No Despachado',
  58 => 'Falsificación',
  59 => 'Faltante de Producto por Agotado',
  60 => 'Fecha de Vencimiento y Lotes Ilegibles, Errados o Ausentes',
  61 => 'Ficha Técnica',
  62 => 'Foil',
  63 => 'Frecuencia de Visita',
  64 => 'Funcionalidad del Empaque',
  65 => 'Garantía del Premio',
  66 => 'General',
  67 => 'Grasa Lateral',
  68 => 'Inconsistencia en Precio/Pagos o Abonos',
  69 => 'Inflado',
  70 => 'Información Nutricional/Ingredientes',
  71 => 'Información Nutricional/Salud',
  72 => 'Ingreso Página Web',
  73 => 'Inscripción',
  74 => 'Inscrito',
  75 => 'Insuficiente, Ausente o Excesivo',
  76 => 'Interesado',
  77 => 'Inventario No Realizado',
  78 => 'Lechoso',
  79 => 'Líder Ventas por Catálogo',
  80 => 'Llegó Tarde',
  81 => 'Lo Facturado No es lo Entregado',
  82 => 'Mal Estado del Empaque',
  83 => 'Mala Presentación del Producto',
  84 => 'Manejo de Producto',
  85 => 'Mantenimiento Mal Realizado',
  86 => 'Mantenimiento No Realizado',
  87 => 'Máquinas Dispensadoras',
  88 => 'Mecánica',
  89 => 'Mecánica de la Campaña/Promoción',
  90 => 'Mercaderismo/Impulso',
  91 => 'Montaje de Nuevos Negocios',
  92 => 'Movilización No Realizada',
  93 => 'Neveras',
  94 => 'No Atribuible a Compañía',
  95 => 'No Han Recogido',
  96 => 'No Llegó',
  97 => 'No Llegó la Promoción',
  98 => 'No llegó/No Está en el Sistema',
  99 => 'Objetos Extraño',
  100 => 'Objetos Extraño Metálico',
  101 => 'Ofrece Nuevos Servicios',
  102 => 'Olor',
  103 => 'Otros',
  104 => 'Oxidado',
  105 => 'Pedido no Tomado por Políticas Comerciales',
  106 => 'Pérdida de Vacío',
  107 => 'Personal Call Center',
  108 => 'Personal de Activos',
  109 => 'Personal de la Compañía',
  110 => 'Personal Técnico',
  111 => 'Peso Inferior al Declarado',
  112 => 'Premia tu Cliente',
  113 => 'Premio',
  114 => 'Presencia de Moho/Hongos',
  115 => 'Problemas con su Usuario',
  116 => 'Problemas de Visualización/No Carga la Página',
  117 => 'Producto Partido',
  118 => 'Producto Próximo a Vencer',
  119 => 'Producto Vencido',
  120 => 'Publicidad Engañosa',
  121 => 'Quebrado',
  122 => 'Recogida',
  123 => 'Redención de Premios',
  124 => 'Redes Sociales',
  125 => 'Referencias Restringidas',
  126 => 'Registro Sanitario',
  127 => 'Rendimiento',
  128 => 'Sabor',
  129 => 'Salud Afectada',
  130 => 'Sellado',
  131 => 'Sellos',
  132 => 'Solicitudes del Cliente',
  133 => 'Textura',
  134 => 'Toma de Pedido Devolución',
  135 => 'Toma de Pedido ERP',
  136 => 'Toma de Pedido Manual',
  137 => 'Usuario y Contraseña Para Ingresar',
  138 => 'Vendedor/Líder/Gerente',
  139 => 'Venta Previa a Temporada',
  140 => 'Ventana de Innovación',
  141 => 'Verde',
  142 => 'Verifica Estatus Premio',
  143 => 'Visualización/Cargue de Página/Navegación',
  144 => 'Retraso o Ausencia de respuesta',
  145 => 'Ofrece nuevos productos y publicidad',
  146 => 'Ofrece nuevas Máquinas',
  147 => 'Ofrece procesos logísticos y de Tecnologia',
  148 => 'Nuevo Nit',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_pregunta2_list.php

 // created: 2016-09-01 14:18:43

$app_list_strings['sasa_pregunta2_list']=array (
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_departamento_c_list.php

 // created: 2016-09-05 14:57:09

$app_list_strings['sasa_departamento_c_list']=array (
  0 => 'ANTIOQUIA',
  1 => 'ATLÁNTICO',
  2 => 'BOGOTÁ, D.C.',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_estratosocial_list.php

 // created: 2016-09-01 14:45:52

$app_list_strings['sasa_estratosocial_list']=array (
  '' => '',
  1 => '1',
  2 => '2',
  3 => '3',
  4 => '4',
  5 => '5',
  6 => '6',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipo_reunion_c_list.php

 // created: 2016-09-04 16:09:54

$app_list_strings['sasa_tipo_reunion_c_list']=array (
  '' => '',
  0 => 'Visita comercial',
  1 => 'Visita técnica',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_lead_source_dom.php

 // created: 2016-09-05 17:01:12

$app_list_strings['lead_source_dom']=array (
  '' => '',
  0 => 'Autorización de Datos',
  1 => 'Colaborador',
  2 => 'Correo Electrónico',
  3 => 'Ferias y Eventos',
  4 => 'Iniciativa Propia',
  5 => 'Medio Digital',
  6 => 'Medios Masivos',
  7 => 'Otros',
  8 => 'Referido',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_account_type_dom.php

 // created: 2016-09-11 22:20:07

$app_list_strings['account_type_dom']=array (
  '' => '',
  0 => 'Si',
  1 => 'No',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_nut_sociedad_list.php

 // created: 2016-08-13 19:47:22

$app_list_strings['nut_sociedad_list']=array (
  'NO' => 'NO',
  'ME' => 'ME',
  'CN' => 'CN',
  'CO' => 'CO',
  'PO' => 'PO',
  'SN' => 'SN',
  'LR' => 'LR',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_record_type_display.php

 // created: 2016-06-30 00:25:54

$app_list_strings['record_type_display']=array (
  '' => '',
  'Accounts' => 'Cuenta',
  'Opportunities' => 'Oportunidad',
  'Cases' => 'Caso',
  'Leads' => 'Cliente Potencial',
  'Contacts' => 'Contactos',
  'Products' => 'Línea de la Oferta',
  'Quotes' => 'Presupuesto',
  'Bugs' => 'Incidencia',
  'Project' => 'Proyecto',
  'Prospects' => 'Público Objetivo',
  'ProjectTask' => 'Tarea de Proyecto',
  'Tasks' => 'Tarea',
  'KBContents' => 'Base de Conocimiento',
  'RevenueLineItems' => 'Líneas de Ingreso',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sasa_festivos.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutf_festivos'] = 'Festivos';
$app_list_strings['moduleListSingular']['nutf_festivos'] = 'Festivo';
$app_list_strings['timezone_dom']['Africa/Algiers'] = 'Africa/Algiers';
$app_list_strings['timezone_dom']['Africa/Luanda'] = 'Africa/Luanda';
$app_list_strings['timezone_dom']['Africa/Porto-Novo'] = 'Africa/Porto-Novo';
$app_list_strings['timezone_dom']['Africa/Gaborone'] = 'Africa/Gaborone';
$app_list_strings['timezone_dom']['Africa/Ouagadougou'] = 'Africa/Ouagadougou';
$app_list_strings['timezone_dom']['Africa/Bujumbura'] = 'Africa/Bujumbura';
$app_list_strings['timezone_dom']['Africa/Douala'] = 'Africa/Douala';
$app_list_strings['timezone_dom']['Atlantic/Cape_Verde'] = 'Atlantic/Cape_Verde';
$app_list_strings['timezone_dom']['Africa/Bangui'] = 'Africa/Bangui';
$app_list_strings['timezone_dom']['Africa/Ndjamena'] = 'Africa/Ndjamena';
$app_list_strings['timezone_dom']['Indian/Comoro'] = 'Indian/Comoro';
$app_list_strings['timezone_dom']['Africa/Kinshasa'] = 'Africa/Kinshasa';
$app_list_strings['timezone_dom']['Africa/Lubumbashi'] = 'Africa/Lubumbashi';
$app_list_strings['timezone_dom']['Africa/Brazzaville'] = 'Africa/Brazzaville';
$app_list_strings['timezone_dom']['Africa/Abidjan'] = 'Africa/Abidjan';
$app_list_strings['timezone_dom']['Africa/Djibouti'] = 'Africa/Djibouti';
$app_list_strings['timezone_dom']['Africa/Cairo'] = 'Africa/Cairo';
$app_list_strings['timezone_dom']['Africa/Malabo'] = 'Africa/Malabo';
$app_list_strings['timezone_dom']['Africa/Asmera'] = 'Africa/Asmera';
$app_list_strings['timezone_dom']['Africa/Addis_Ababa'] = 'Africa/Addis_Ababa';
$app_list_strings['timezone_dom']['Africa/Libreville'] = 'Africa/Libreville';
$app_list_strings['timezone_dom']['Africa/Banjul'] = 'Africa/Banjul';
$app_list_strings['timezone_dom']['Africa/Accra'] = 'Africa/Accra';
$app_list_strings['timezone_dom']['Africa/Conakry'] = 'Africa/Conakry';
$app_list_strings['timezone_dom']['Africa/Bissau'] = 'Africa/Bissau';
$app_list_strings['timezone_dom']['Africa/Nairobi'] = 'Africa/Nairobi';
$app_list_strings['timezone_dom']['Africa/Maseru'] = 'Africa/Maseru';
$app_list_strings['timezone_dom']['Africa/Monrovia'] = 'Africa/Monrovia';
$app_list_strings['timezone_dom']['Africa/Tripoli'] = 'Africa/Tripoli';
$app_list_strings['timezone_dom']['Indian/Antananarivo'] = 'Indian/Antananarivo';
$app_list_strings['timezone_dom']['Africa/Blantyre'] = 'Africa/Blantyre';
$app_list_strings['timezone_dom']['Africa/Bamako'] = 'Africa/Bamako';
$app_list_strings['timezone_dom']['Africa/Nouakchott'] = 'Africa/Nouakchott';
$app_list_strings['timezone_dom']['Indian/Mauritius'] = 'Indian/Mauritius';
$app_list_strings['timezone_dom']['Indian/Mayotte'] = 'Indian/Mayotte';
$app_list_strings['timezone_dom']['Africa/Casablanca'] = 'Africa/Casablanca';
$app_list_strings['timezone_dom']['Africa/El_Aaiun'] = 'Africa/El_Aaiun';
$app_list_strings['timezone_dom']['Africa/Maputo'] = 'Africa/Maputo';
$app_list_strings['timezone_dom']['Africa/Windhoek'] = 'Africa/Windhoek';
$app_list_strings['timezone_dom']['Africa/Niamey'] = 'Africa/Niamey';
$app_list_strings['timezone_dom']['Africa/Lagos'] = 'Africa/Lagos';
$app_list_strings['timezone_dom']['Indian/Reunion'] = 'Indian/Reunion';
$app_list_strings['timezone_dom']['Africa/Kigali'] = 'Africa/Kigali';
$app_list_strings['timezone_dom']['Atlantic/St_Helena'] = 'Atlantic/St_Helena';
$app_list_strings['timezone_dom']['Africa/Sao_Tome'] = 'Africa/Sao_Tome';
$app_list_strings['timezone_dom']['Africa/Dakar'] = 'Africa/Dakar';
$app_list_strings['timezone_dom']['Indian/Mahe'] = 'Indian/Mahe';
$app_list_strings['timezone_dom']['Africa/Freetown'] = 'Africa/Freetown';
$app_list_strings['timezone_dom']['Africa/Mogadishu'] = 'Africa/Mogadishu';
$app_list_strings['timezone_dom']['Africa/Johannesburg'] = 'Africa/Johannesburg';
$app_list_strings['timezone_dom']['Africa/Khartoum'] = 'Africa/Khartoum';
$app_list_strings['timezone_dom']['Africa/Mbabane'] = 'Africa/Mbabane';
$app_list_strings['timezone_dom']['Africa/Dar_es_Salaam'] = 'Africa/Dar_es_Salaam';
$app_list_strings['timezone_dom']['Africa/Lome'] = 'Africa/Lome';
$app_list_strings['timezone_dom']['Africa/Tunis'] = 'Africa/Tunis';
$app_list_strings['timezone_dom']['Africa/Kampala'] = 'Africa/Kampala';
$app_list_strings['timezone_dom']['Africa/Lusaka'] = 'Africa/Lusaka';
$app_list_strings['timezone_dom']['Africa/Harare'] = 'Africa/Harare';
$app_list_strings['timezone_dom']['Antarctica/Casey'] = 'Antarctica/Casey';
$app_list_strings['timezone_dom']['Antarctica/Davis'] = 'Antarctica/Davis';
$app_list_strings['timezone_dom']['Antarctica/Mawson'] = 'Antarctica/Mawson';
$app_list_strings['timezone_dom']['Indian/Kerguelen'] = 'Indian/Kerguelen';
$app_list_strings['timezone_dom']['Antarctica/DumontDUrville'] = 'Antarctica/DumontDUrville';
$app_list_strings['timezone_dom']['Antarctica/Syowa'] = 'Antarctica/Syowa';
$app_list_strings['timezone_dom']['Antarctica/Vostok'] = 'Antarctica/Vostok';
$app_list_strings['timezone_dom']['Antarctica/Rothera'] = 'Antarctica/Rothera';
$app_list_strings['timezone_dom']['Antarctica/Palmer'] = 'Antarctica/Palmer';
$app_list_strings['timezone_dom']['Antarctica/McMurdo'] = 'Antarctica/McMurdo';
$app_list_strings['timezone_dom']['Asia/Kabul'] = 'Asia/Kabul';
$app_list_strings['timezone_dom']['Asia/Yerevan'] = 'Asia/Yerevan';
$app_list_strings['timezone_dom']['Asia/Baku'] = 'Asia/Baku';
$app_list_strings['timezone_dom']['Asia/Bahrain'] = 'Asia/Bahrain';
$app_list_strings['timezone_dom']['Asia/Dhaka'] = 'Asia/Dhaka';
$app_list_strings['timezone_dom']['Asia/Thimphu'] = 'Asia/Thimphu';
$app_list_strings['timezone_dom']['Indian/Chagos'] = 'Indian/Chagos';
$app_list_strings['timezone_dom']['Asia/Brunei'] = 'Asia/Brunei';
$app_list_strings['timezone_dom']['Asia/Rangoon'] = 'Asia/Rangoon';
$app_list_strings['timezone_dom']['Asia/Phnom_Penh'] = 'Asia/Phnom_Penh';
$app_list_strings['timezone_dom']['Asia/Beijing'] = 'Asia/Beijing';
$app_list_strings['timezone_dom']['Asia/Harbin'] = 'Asia/Harbin';
$app_list_strings['timezone_dom']['Asia/Shanghai'] = 'Asia/Shanghai';
$app_list_strings['timezone_dom']['Asia/Chongqing'] = 'Asia/Chongqing';
$app_list_strings['timezone_dom']['Asia/Urumqi'] = 'Asia/Urumqi';
$app_list_strings['timezone_dom']['Asia/Kashgar'] = 'Asia/Kashgar';
$app_list_strings['timezone_dom']['Asia/Hong_Kong'] = 'Asia/Hong_Kong';
$app_list_strings['timezone_dom']['Asia/Taipei'] = 'Asia/Taipei';
$app_list_strings['timezone_dom']['Asia/Macau'] = 'Asia/Macau';
$app_list_strings['timezone_dom']['Asia/Nicosia'] = 'Asia/Nicosia';
$app_list_strings['timezone_dom']['Asia/Tbilisi'] = 'Asia/Tbilisi';
$app_list_strings['timezone_dom']['Asia/Dili'] = 'Asia/Dili';
$app_list_strings['timezone_dom']['Asia/Calcutta'] = 'Asia/Calcutta';
$app_list_strings['timezone_dom']['Asia/Jakarta'] = 'Asia/Jakarta';
$app_list_strings['timezone_dom']['Asia/Pontianak'] = 'Asia/Pontianak';
$app_list_strings['timezone_dom']['Asia/Makassar'] = 'Asia/Makassar';
$app_list_strings['timezone_dom']['Asia/Jayapura'] = 'Asia/Jayapura';
$app_list_strings['timezone_dom']['Asia/Tehran'] = 'Asia/Tehran';
$app_list_strings['timezone_dom']['Asia/Baghdad'] = 'Asia/Baghdad';
$app_list_strings['timezone_dom']['Asia/Jerusalem'] = 'Asia/Jerusalem';
$app_list_strings['timezone_dom']['Asia/Tokyo'] = 'Asia/Tokyo';
$app_list_strings['timezone_dom']['Asia/Amman'] = 'Asia/Amman';
$app_list_strings['timezone_dom']['Asia/Almaty'] = 'Asia/Almaty';
$app_list_strings['timezone_dom']['Asia/Qyzylorda'] = 'Asia/Qyzylorda';
$app_list_strings['timezone_dom']['Asia/Aqtobe'] = 'Asia/Aqtobe';
$app_list_strings['timezone_dom']['Asia/Aqtau'] = 'Asia/Aqtau';
$app_list_strings['timezone_dom']['Asia/Oral'] = 'Asia/Oral';
$app_list_strings['timezone_dom']['Asia/Bishkek'] = 'Asia/Bishkek';
$app_list_strings['timezone_dom']['Asia/Seoul'] = 'Asia/Seoul';
$app_list_strings['timezone_dom']['Asia/Pyongyang'] = 'Asia/Pyongyang';
$app_list_strings['timezone_dom']['Asia/Kuwait'] = 'Asia/Kuwait';
$app_list_strings['timezone_dom']['Asia/Vientiane'] = 'Asia/Vientiane';
$app_list_strings['timezone_dom']['Asia/Beirut'] = 'Asia/Beirut';
$app_list_strings['timezone_dom']['Asia/Kuala_Lumpur'] = 'Asia/Kuala_Lumpur';
$app_list_strings['timezone_dom']['Asia/Kuching'] = 'Asia/Kuching';
$app_list_strings['timezone_dom']['Indian/Maldives'] = 'Indian/Maldives';
$app_list_strings['timezone_dom']['Asia/Hovd'] = 'Asia/Hovd';
$app_list_strings['timezone_dom']['Asia/Ulaanbaatar'] = 'Asia/Ulaanbaatar';
$app_list_strings['timezone_dom']['Asia/Choibalsan'] = 'Asia/Choibalsan';
$app_list_strings['timezone_dom']['Asia/Katmandu'] = 'Asia/Katmandu';
$app_list_strings['timezone_dom']['Asia/Muscat'] = 'Asia/Muscat';
$app_list_strings['timezone_dom']['Asia/Karachi'] = 'Asia/Karachi';
$app_list_strings['timezone_dom']['Asia/Gaza'] = 'Asia/Gaza';
$app_list_strings['timezone_dom']['Asia/Manila'] = 'Asia/Manila';
$app_list_strings['timezone_dom']['Asia/Qatar'] = 'Asia/Qatar';
$app_list_strings['timezone_dom']['Asia/Riyadh'] = 'Asia/Riyadh';
$app_list_strings['timezone_dom']['Asia/Singapore'] = 'Asia/Singapore';
$app_list_strings['timezone_dom']['Asia/Colombo'] = 'Asia/Colombo';
$app_list_strings['timezone_dom']['Asia/Damascus'] = 'Asia/Damascus';
$app_list_strings['timezone_dom']['Asia/Dushanbe'] = 'Asia/Dushanbe';
$app_list_strings['timezone_dom']['Asia/Bangkok'] = 'Asia/Bangkok';
$app_list_strings['timezone_dom']['Asia/Ashgabat'] = 'Asia/Ashgabat';
$app_list_strings['timezone_dom']['Asia/Dubai'] = 'Asia/Dubai';
$app_list_strings['timezone_dom']['Asia/Samarkand'] = 'Asia/Samarkand';
$app_list_strings['timezone_dom']['Asia/Tashkent'] = 'Asia/Tashkent';
$app_list_strings['timezone_dom']['Asia/Saigon'] = 'Asia/Saigon';
$app_list_strings['timezone_dom']['Asia/Aden'] = 'Asia/Aden';
$app_list_strings['timezone_dom']['Australia/Darwin'] = 'Australia/Darwin';
$app_list_strings['timezone_dom']['Australia/Perth'] = 'Australia/Perth';
$app_list_strings['timezone_dom']['Australia/Brisbane'] = 'Australia/Brisbane';
$app_list_strings['timezone_dom']['Australia/Lindeman'] = 'Australia/Lindeman';
$app_list_strings['timezone_dom']['Australia/Adelaide'] = 'Australia/Adelaide';
$app_list_strings['timezone_dom']['Australia/Hobart'] = 'Australia/Hobart';
$app_list_strings['timezone_dom']['Australia/Currie'] = 'Australia/Currie';
$app_list_strings['timezone_dom']['Australia/Melbourne'] = 'Australia/Melbourne';
$app_list_strings['timezone_dom']['Australia/Sydney'] = 'Australia/Sydney';
$app_list_strings['timezone_dom']['Australia/Broken_Hill'] = 'Australia/Broken_Hill';
$app_list_strings['timezone_dom']['Indian/Christmas'] = 'Indian/Christmas';
$app_list_strings['timezone_dom']['Pacific/Rarotonga'] = 'Pacific/Rarotonga';
$app_list_strings['timezone_dom']['Indian/Cocos'] = 'Indian/Cocos';
$app_list_strings['timezone_dom']['Pacific/Fiji'] = 'Pacific/Fiji';
$app_list_strings['timezone_dom']['Pacific/Gambier'] = 'Pacific/Gambier';
$app_list_strings['timezone_dom']['Pacific/Marquesas'] = 'Pacific/Marquesas';
$app_list_strings['timezone_dom']['Pacific/Tahiti'] = 'Pacific/Tahiti';
$app_list_strings['timezone_dom']['Pacific/Guam'] = 'Pacific/Guam';
$app_list_strings['timezone_dom']['Pacific/Tarawa'] = 'Pacific/Tarawa';
$app_list_strings['timezone_dom']['Pacific/Enderbury'] = 'Pacific/Enderbury';
$app_list_strings['timezone_dom']['Pacific/Kiritimati'] = 'Pacific/Kiritimati';
$app_list_strings['timezone_dom']['Pacific/Saipan'] = 'Pacific/Saipan';
$app_list_strings['timezone_dom']['Pacific/Majuro'] = 'Pacific/Majuro';
$app_list_strings['timezone_dom']['Pacific/Kwajalein'] = 'Pacific/Kwajalein';
$app_list_strings['timezone_dom']['Pacific/Truk'] = 'Pacific/Truk';
$app_list_strings['timezone_dom']['Pacific/Ponape'] = 'Pacific/Ponape';
$app_list_strings['timezone_dom']['Pacific/Kosrae'] = 'Pacific/Kosrae';
$app_list_strings['timezone_dom']['Pacific/Nauru'] = 'Pacific/Nauru';
$app_list_strings['timezone_dom']['Pacific/Noumea'] = 'Pacific/Noumea';
$app_list_strings['timezone_dom']['Pacific/Auckland'] = 'Pacific/Auckland';
$app_list_strings['timezone_dom']['Pacific/Chatham'] = 'Pacific/Chatham';
$app_list_strings['timezone_dom']['Pacific/Niue'] = 'Pacific/Niue';
$app_list_strings['timezone_dom']['Pacific/Norfolk'] = 'Pacific/Norfolk';
$app_list_strings['timezone_dom']['Pacific/Palau'] = 'Pacific/Palau';
$app_list_strings['timezone_dom']['Pacific/Port_Moresby'] = 'Pacific/Port_Moresby';
$app_list_strings['timezone_dom']['Pacific/Pitcairn'] = 'Pacific/Pitcairn';
$app_list_strings['timezone_dom']['Pacific/Pago_Pago'] = 'Pacific/Pago_Pago';
$app_list_strings['timezone_dom']['Pacific/Apia'] = 'Pacific/Apia';
$app_list_strings['timezone_dom']['Pacific/Guadalcanal'] = 'Pacific/Guadalcanal';
$app_list_strings['timezone_dom']['Pacific/Fakaofo'] = 'Pacific/Fakaofo';
$app_list_strings['timezone_dom']['Pacific/Tongatapu'] = 'Pacific/Tongatapu';
$app_list_strings['timezone_dom']['Pacific/Funafuti'] = 'Pacific/Funafuti';
$app_list_strings['timezone_dom']['Pacific/Johnston'] = 'Pacific/Johnston';
$app_list_strings['timezone_dom']['Pacific/Midway'] = 'Pacific/Midway';
$app_list_strings['timezone_dom']['Pacific/Wake'] = 'Pacific/Wake';
$app_list_strings['timezone_dom']['Pacific/Efate'] = 'Pacific/Efate';
$app_list_strings['timezone_dom']['Pacific/Wallis'] = 'Pacific/Wallis';
$app_list_strings['timezone_dom']['Europe/London'] = 'Europe/London';
$app_list_strings['timezone_dom']['Europe/Dublin'] = 'Europe/Dublin';
$app_list_strings['timezone_dom']['WET'] = 'WET';
$app_list_strings['timezone_dom']['CET'] = 'CET';
$app_list_strings['timezone_dom']['MET'] = 'MET';
$app_list_strings['timezone_dom']['EET'] = 'EET';
$app_list_strings['timezone_dom']['Europe/Tirane'] = 'Europe/Tirane';
$app_list_strings['timezone_dom']['Europe/Andorra'] = 'Europe/Andorra';
$app_list_strings['timezone_dom']['Europe/Vienna'] = 'Europe/Vienna';
$app_list_strings['timezone_dom']['Europe/Minsk'] = 'Europe/Minsk';
$app_list_strings['timezone_dom']['Europe/Brussels'] = 'Europa/Bruselas';
$app_list_strings['timezone_dom']['Europe/Sofia'] = 'Europa/Sofia';
$app_list_strings['timezone_dom']['Europe/Prague'] = 'Europa/Praga';
$app_list_strings['timezone_dom']['Europe/Copenhagen'] = 'Europa y Copenhague';
$app_list_strings['timezone_dom']['Atlantic/Faeroe'] = 'Atlantic/Faeroe';
$app_list_strings['timezone_dom']['America/Danmarkshavn'] = 'America/Danmarkshavn';
$app_list_strings['timezone_dom']['America/Scoresbysund'] = 'America/Scoresbysund';
$app_list_strings['timezone_dom']['America/Godthab'] = 'America/Godthab';
$app_list_strings['timezone_dom']['America/Thule'] = 'America/Thule';
$app_list_strings['timezone_dom']['Europe/Tallinn'] = 'Europa/Tallin';
$app_list_strings['timezone_dom']['Europe/Helsinki'] = 'Europa/Helsinki';
$app_list_strings['timezone_dom']['Europe/Paris'] = 'Europa/París';
$app_list_strings['timezone_dom']['Europe/Berlin'] = 'Europa/Berlín';
$app_list_strings['timezone_dom']['Europe/Gibraltar'] = 'Europa/Gibraltar';
$app_list_strings['timezone_dom']['Europe/Athens'] = 'Europa/Atenas';
$app_list_strings['timezone_dom']['Europe/Budapest'] = 'Europa/Budapest';
$app_list_strings['timezone_dom']['Atlantic/Reykjavik'] = 'Atlantic/Reykjavik';
$app_list_strings['timezone_dom']['Europe/Rome'] = 'Europa/Roma';
$app_list_strings['timezone_dom']['Europe/Riga'] = 'Europa/Riga';
$app_list_strings['timezone_dom']['Europe/Vaduz'] = 'Europa/Vaduz';
$app_list_strings['timezone_dom']['Europe/Vilnius'] = 'Europa/Vilnius';
$app_list_strings['timezone_dom']['Europe/Luxembourg'] = 'Europa/Luxemburgo';
$app_list_strings['timezone_dom']['Europe/Malta'] = 'Europa/Malta';
$app_list_strings['timezone_dom']['Europe/Chisinau'] = 'Europa/Chisinau';
$app_list_strings['timezone_dom']['Europe/Monaco'] = 'Europa/Mónaco';
$app_list_strings['timezone_dom']['Europe/Amsterdam'] = 'Europa/Amsterdam';
$app_list_strings['timezone_dom']['Europe/Oslo'] = 'Europa/Oslo';
$app_list_strings['timezone_dom']['Europe/Warsaw'] = 'Europa/Varsovia';
$app_list_strings['timezone_dom']['Europe/Lisbon'] = 'Europa/Lisboa';
$app_list_strings['timezone_dom']['Atlantic/Azores'] = 'Atlantic/Azores';
$app_list_strings['timezone_dom']['Atlantic/Madeira'] = 'Atlantic/Madeira';
$app_list_strings['timezone_dom']['Europe/Bucharest'] = 'Europa/Bucarest';
$app_list_strings['timezone_dom']['Europe/Kaliningrad'] = 'Europa/Kaliningrado';
$app_list_strings['timezone_dom']['Europe/Moscow'] = 'Europa/Moscú';
$app_list_strings['timezone_dom']['Europe/Samara'] = 'Europa/Samara';
$app_list_strings['timezone_dom']['Asia/Yekaterinburg'] = 'Asia/Yekaterinburg';
$app_list_strings['timezone_dom']['Asia/Omsk'] = 'Asia/Omsk';
$app_list_strings['timezone_dom']['Asia/Novosibirsk'] = 'Asia/Novosibirsk';
$app_list_strings['timezone_dom']['Asia/Krasnoyarsk'] = 'Asia/Krasnoyarsk';
$app_list_strings['timezone_dom']['Asia/Irkutsk'] = 'Asia/Irkutsk';
$app_list_strings['timezone_dom']['Asia/Yakutsk'] = 'Asia/Yakutsk';
$app_list_strings['timezone_dom']['Asia/Vladivostok'] = 'Asia/Vladivostok';
$app_list_strings['timezone_dom']['Asia/Sakhalin'] = 'Asia/Sakhalin';
$app_list_strings['timezone_dom']['Asia/Magadan'] = 'Asia/Magadan';
$app_list_strings['timezone_dom']['Asia/Kamchatka'] = 'Asia/Kamchatka';
$app_list_strings['timezone_dom']['Asia/Anadyr'] = 'Asia/Anadyr';
$app_list_strings['timezone_dom']['Europe/Belgrade'] = 'Europe/Belgrade';
$app_list_strings['timezone_dom']['Europe/Madrid'] = 'Europe/Madrid';
$app_list_strings['timezone_dom']['Africa/Ceuta'] = 'Africa/Ceuta';
$app_list_strings['timezone_dom']['Atlantic/Canary'] = 'Atlantic/Canary';
$app_list_strings['timezone_dom']['Europe/Stockholm'] = 'Europe/Stockholm';
$app_list_strings['timezone_dom']['Europe/Zurich'] = 'Europe/Zurich';
$app_list_strings['timezone_dom']['Europe/Istanbul'] = 'Europe/Istanbul';
$app_list_strings['timezone_dom']['Europe/Kiev'] = 'Europe/Kiev';
$app_list_strings['timezone_dom']['Europe/Uzhgorod'] = 'Europe/Uzhgorod';
$app_list_strings['timezone_dom']['Europe/Zaporozhye'] = 'Europe/Zaporozhye';
$app_list_strings['timezone_dom']['Europe/Simferopol'] = 'Europe/Simferopol';
$app_list_strings['timezone_dom']['America/New_York'] = 'America/New_York';
$app_list_strings['timezone_dom']['America/Chicago'] = 'America/Chicago';
$app_list_strings['timezone_dom']['America/North_Dakota/Center'] = 'America/North_Dakota/Center';
$app_list_strings['timezone_dom']['America/Denver'] = 'America/Denver';
$app_list_strings['timezone_dom']['America/Los_Angeles'] = 'America/Los_Angeles';
$app_list_strings['timezone_dom']['America/Juneau'] = 'America/Juneau';
$app_list_strings['timezone_dom']['America/Yakutat'] = 'America/Yakutat';
$app_list_strings['timezone_dom']['America/Anchorage'] = 'America/Anchorage';
$app_list_strings['timezone_dom']['America/Nome'] = 'America/Nome';
$app_list_strings['timezone_dom']['America/Adak'] = 'America/Adak';
$app_list_strings['timezone_dom']['Pacific/Honolulu'] = 'Pacific/Honolulu';
$app_list_strings['timezone_dom']['America/Phoenix'] = 'America/Phoenix';
$app_list_strings['timezone_dom']['America/Boise'] = 'America/Boise';
$app_list_strings['timezone_dom']['America/Indiana/Indianapolis'] = 'America/Indiana/Indianapolis';
$app_list_strings['timezone_dom']['America/Indiana/Marengo'] = 'America/Indiana/Marengo';
$app_list_strings['timezone_dom']['America/Indiana/Knox'] = 'America/Indiana/Knox';
$app_list_strings['timezone_dom']['America/Indiana/Vevay'] = 'America/Indiana/Vevay';
$app_list_strings['timezone_dom']['America/Kentucky/Louisville'] = 'America/Kentucky/Louisville';
$app_list_strings['timezone_dom']['America/Kentucky/Monticello'] = 'America/Kentucky/Monticello';
$app_list_strings['timezone_dom']['America/Detroit'] = 'America/Detroit';
$app_list_strings['timezone_dom']['America/Menominee'] = 'America/Menominee';
$app_list_strings['timezone_dom']['America/St_Johns'] = 'America/St_Johns';
$app_list_strings['timezone_dom']['America/Goose_Bay'] = 'America/Goose_Bay';
$app_list_strings['timezone_dom']['America/Halifax'] = 'America/Halifax';
$app_list_strings['timezone_dom']['America/Glace_Bay'] = 'America/Glace_Bay';
$app_list_strings['timezone_dom']['America/Montreal'] = 'America/Montreal';
$app_list_strings['timezone_dom']['America/Toronto'] = 'America/Toronto';
$app_list_strings['timezone_dom']['America/Thunder_Bay'] = 'America/Thunder_Bay';
$app_list_strings['timezone_dom']['America/Nipigon'] = 'America/Nipigon';
$app_list_strings['timezone_dom']['America/Rainy_River'] = 'America/Rainy_River';
$app_list_strings['timezone_dom']['America/Winnipeg'] = 'America/Winnipeg';
$app_list_strings['timezone_dom']['America/Regina'] = 'America/Regina';
$app_list_strings['timezone_dom']['America/Swift_Current'] = 'America/Swift_Current';
$app_list_strings['timezone_dom']['America/Edmonton'] = 'America/Edmonton';
$app_list_strings['timezone_dom']['America/Vancouver'] = 'America/Vancouver';
$app_list_strings['timezone_dom']['America/Dawson_Creek'] = 'America/Dawson_Creek';
$app_list_strings['timezone_dom']['America/Pangnirtung'] = 'America/Pangnirtung';
$app_list_strings['timezone_dom']['America/Iqaluit'] = 'America/Iqaluit';
$app_list_strings['timezone_dom']['America/Coral_Harbour'] = 'America/Coral_Harbour';
$app_list_strings['timezone_dom']['America/Rankin_Inlet'] = 'America/Rankin_Inlet';
$app_list_strings['timezone_dom']['America/Cambridge_Bay'] = 'America/Cambridge_Bay';
$app_list_strings['timezone_dom']['America/Yellowknife'] = 'America/Yellowknife';
$app_list_strings['timezone_dom']['America/Inuvik'] = 'America/Inuvik';
$app_list_strings['timezone_dom']['America/Whitehorse'] = 'America/Whitehorse';
$app_list_strings['timezone_dom']['America/Dawson'] = 'America/Dawson';
$app_list_strings['timezone_dom']['America/Cancun'] = 'America/Cancun';
$app_list_strings['timezone_dom']['America/Merida'] = 'America/Merida';
$app_list_strings['timezone_dom']['America/Monterrey'] = 'America/Monterrey';
$app_list_strings['timezone_dom']['America/Mexico_City'] = 'America/Mexico_City';
$app_list_strings['timezone_dom']['America/Chihuahua'] = 'America/Chihuahua';
$app_list_strings['timezone_dom']['America/Hermosillo'] = 'America/Hermosillo';
$app_list_strings['timezone_dom']['America/Mazatlan'] = 'America/Mazatlan';
$app_list_strings['timezone_dom']['America/Tijuana'] = 'America/Tijuana';
$app_list_strings['timezone_dom']['America/Anguilla'] = 'America/Anguilla';
$app_list_strings['timezone_dom']['America/Antigua'] = 'America/Antigua';
$app_list_strings['timezone_dom']['America/Nassau'] = 'America/Nassau';
$app_list_strings['timezone_dom']['America/Barbados'] = 'America/Barbados';
$app_list_strings['timezone_dom']['America/Belize'] = 'America/Belize';
$app_list_strings['timezone_dom']['Atlantic/Bermuda'] = 'Atlantic/Bermuda';
$app_list_strings['timezone_dom']['America/Cayman'] = 'America/Cayman';
$app_list_strings['timezone_dom']['America/Costa_Rica'] = 'America/Costa_Rica';
$app_list_strings['timezone_dom']['America/Havana'] = 'America/Havana';
$app_list_strings['timezone_dom']['America/Dominica'] = 'America/Dominica';
$app_list_strings['timezone_dom']['America/Santo_Domingo'] = 'America/Santo_Domingo';
$app_list_strings['timezone_dom']['America/El_Salvador'] = 'America/El_Salvador';
$app_list_strings['timezone_dom']['America/Grenada'] = 'America/Grenada';
$app_list_strings['timezone_dom']['America/Guadeloupe'] = 'America/Guadeloupe';
$app_list_strings['timezone_dom']['America/Guatemala'] = 'America/Guatemala';
$app_list_strings['timezone_dom']['America/Port-au-Prince'] = 'America/Port-au-Prince';
$app_list_strings['timezone_dom']['America/Tegucigalpa'] = 'America/Tegucigalpa';
$app_list_strings['timezone_dom']['America/Jamaica'] = 'America/Jamaica';
$app_list_strings['timezone_dom']['America/Martinique'] = 'America/Martinique';
$app_list_strings['timezone_dom']['America/Montserrat'] = 'America/Montserrat';
$app_list_strings['timezone_dom']['America/Managua'] = 'America/Managua';
$app_list_strings['timezone_dom']['America/Panama'] = 'America/Panama';
$app_list_strings['timezone_dom']['America/Puerto_Rico'] = 'America/Puerto_Rico';
$app_list_strings['timezone_dom']['America/St_Kitts'] = 'America/St_Kitts';
$app_list_strings['timezone_dom']['America/St_Lucia'] = 'America/St_Lucia';
$app_list_strings['timezone_dom']['America/Miquelon'] = 'America/Miquelon';
$app_list_strings['timezone_dom']['America/St_Vincent'] = 'America/St_Vincent';
$app_list_strings['timezone_dom']['America/Grand_Turk'] = 'America/Grand_Turk';
$app_list_strings['timezone_dom']['America/Tortola'] = 'America/Tortola';
$app_list_strings['timezone_dom']['America/St_Thomas'] = 'America/St_Thomas';
$app_list_strings['timezone_dom']['America/Argentina/Buenos_Aires'] = 'America/Argentina/Buenos_Aires';
$app_list_strings['timezone_dom']['America/Argentina/Cordoba'] = 'America/Argentina/Cordoba';
$app_list_strings['timezone_dom']['America/Argentina/Tucuman'] = 'America/Argentina/Tucuman';
$app_list_strings['timezone_dom']['America/Argentina/La_Rioja'] = 'America/Argentina/La_Rioja';
$app_list_strings['timezone_dom']['America/Argentina/San_Juan'] = 'America/Argentina/San_Juan';
$app_list_strings['timezone_dom']['America/Argentina/Jujuy'] = 'America/Argentina/Jujuy';
$app_list_strings['timezone_dom']['America/Argentina/Catamarca'] = 'America/Argentina/Catamarca';
$app_list_strings['timezone_dom']['America/Argentina/Mendoza'] = 'America/Argentina/Mendoza';
$app_list_strings['timezone_dom']['America/Argentina/Rio_Gallegos'] = 'America/Argentina/Rio_Gallegos';
$app_list_strings['timezone_dom']['America/Argentina/Ushuaia'] = 'America/Argentina/Ushuaia';
$app_list_strings['timezone_dom']['America/Aruba'] = 'America/Aruba';
$app_list_strings['timezone_dom']['America/La_Paz'] = 'America/La_Paz';
$app_list_strings['timezone_dom']['America/Noronha'] = 'America/Noronha';
$app_list_strings['timezone_dom']['America/Belem'] = 'America/Belem';
$app_list_strings['timezone_dom']['America/Fortaleza'] = 'America/Fortaleza';
$app_list_strings['timezone_dom']['America/Recife'] = 'America/Recife';
$app_list_strings['timezone_dom']['America/Araguaina'] = 'America/Araguaina';
$app_list_strings['timezone_dom']['America/Maceio'] = 'America/Maceio';
$app_list_strings['timezone_dom']['America/Bahia'] = 'America/Bahia';
$app_list_strings['timezone_dom']['America/Sao_Paulo'] = 'America/Sao_Paulo';
$app_list_strings['timezone_dom']['America/Campo_Grande'] = 'America/Campo_Grande';
$app_list_strings['timezone_dom']['America/Cuiaba'] = 'America/Cuiaba';
$app_list_strings['timezone_dom']['America/Porto_Velho'] = 'America/Porto_Velho';
$app_list_strings['timezone_dom']['America/Boa_Vista'] = 'America/Boa_Vista';
$app_list_strings['timezone_dom']['America/Manaus'] = 'America/Manaus';
$app_list_strings['timezone_dom']['America/Eirunepe'] = 'America/Eirunepe';
$app_list_strings['timezone_dom']['America/Rio_Branco'] = 'America/Rio_Branco';
$app_list_strings['timezone_dom']['America/Santiago'] = 'America/Santiago';
$app_list_strings['timezone_dom']['Pacific/Easter'] = 'Pacific/Easter';
$app_list_strings['timezone_dom']['America/Bogota'] = 'America/Bogota';
$app_list_strings['timezone_dom']['America/Curacao'] = 'America/Curacao';
$app_list_strings['timezone_dom']['America/Guayaquil'] = 'America/Guayaquil';
$app_list_strings['timezone_dom']['Pacific/Galapagos'] = 'Pacific/Galapagos';
$app_list_strings['timezone_dom']['Atlantic/Stanley'] = 'Atlantic/Stanley';
$app_list_strings['timezone_dom']['America/Cayenne'] = 'America/Cayenne';
$app_list_strings['timezone_dom']['America/Guyana'] = 'America/Guyana';
$app_list_strings['timezone_dom']['America/Asuncion'] = 'America/Asuncion';
$app_list_strings['timezone_dom']['America/Lima'] = 'America/Lima';
$app_list_strings['timezone_dom']['Atlantic/South_Georgia'] = 'Atlantic/South_Georgia';
$app_list_strings['timezone_dom']['America/Paramaribo'] = 'America/Paramaribo';
$app_list_strings['timezone_dom']['America/Port_of_Spain'] = 'America/Port_of_Spain';
$app_list_strings['timezone_dom']['America/Montevideo'] = 'America/Montevideo';
$app_list_strings['timezone_dom']['America/Caracas'] = 'America/Caracas';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipo_tarea_list.php

 // created: 2016-09-04 12:22:25

$app_list_strings['sasa_tipo_tarea_list']=array (
  '' => '',
  1 => 'Opción de selección de valor de lista',
  50 => 'Opción de selección de múltiples valores',
  100 => 'Opción de selección de fecha',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.historico.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nuth_sasa_historicos'] = 'Historicos';
$app_list_strings['moduleListSingular']['nuth_sasa_historicos'] = 'Historico';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.maestro_activos.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutac_maestro_activos'] = 'Maestro activos';
$app_list_strings['moduleListSingular']['nutac_maestro_activos'] = 'Maestro activo';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.Tipificacion_Casos.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['SASA_Tificacion_Casos'] = 'Tipificación de Casos';
$app_list_strings['moduleListSingular']['SASA_Tificacion_Casos'] = 'Tipificación de Caso';
$app_list_strings['sasa_motivo_list'][0] = 'Información';
$app_list_strings['sasa_motivo_list'][1] = 'Solicitud';
$app_list_strings['sasa_motivo_list'][2] = 'Queja';
$app_list_strings['sasa_motivo_list'][''] = '';
$app_list_strings['sasa_proceso_c_list'][0] = 'Servicio';
$app_list_strings['sasa_proceso_c_list'][1] = 'Comercial';
$app_list_strings['sasa_proceso_c_list'][2] = 'Logística';
$app_list_strings['sasa_subcategoria_c_list'][0] = 'Consulta';
$app_list_strings['sasa_subcategoria_c_list'][1] = 'Devolución de dinero';
$app_list_strings['sasa_subcategoria_c_list'][2] = 'Otros';
$app_list_strings['sasa_detallle_c_list'][0] = 'Abollado';
$app_list_strings['sasa_detallle_c_list'][1] = 'Inflado';
$app_list_strings['sasa_detallle_c_list'][2] = 'General';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_motivo_retiro_list.php

 // created: 2016-09-27 01:13:53

$app_list_strings['sasa_motivo_retiro_list']=array (
  '' => '',
  3 => 'Comercial',
  4 => 'Logística',
  2 => 'Operaciones',
  5 => 'Servicio al cliente',
  1 => 'Tecnico(a)',
  0 => 'Trade',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.maestro_vendedores.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutmv_maestro_vendedores'] = 'Maestro Vendedores';
$app_list_strings['moduleListSingular']['nutmv_maestro_vendedores'] = 'Maestro Vendedor';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_lead_status_dom.php

 // created: 2016-10-03 23:13:54

$app_list_strings['lead_status_dom']=array (
  '' => '',
  'New' => 'Nuevo',
  'Assigned' => 'Asignado',
  'In Process' => 'En proceso',
  'Converted' => 'Convertido',
  'Recycled' => 'Reciclado',
  'Dead' => 'No cumple',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_inicioproceso_c_list.php

 // created: 2016-09-27 15:08:33

$app_list_strings['sasa_inicioproceso_c_list']=array (
  0 => '0',
  1 => '1',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipodeservicio_c_list.php

 // created: 2016-10-08 01:18:58

$app_list_strings['sasa_tipodeservicio_c_list']=array (
  '' => '',
  'Fumigacion' => 'Fumigacion',
  'Cambio de chapa' => 'Cambio de chapa',
  'Cambio de boquilla' => 'Cambio de boquilla',
  'Reposicion de llave' => 'Reposicion de llave',
  'Accesorio mobileto' => 'Accesorio mobileto',
  'Instalacion medios de pago' => 'Instalacion medios de pago',
  'Modificacion de portafolio' => 'Modificacion de portafolio',
  'Anclajes' => 'Anclajes',
  'Cambio de cilindro' => 'Cambio de cilindro',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_relacion_list.php

 // created: 2016-09-06 16:04:47

$app_list_strings['sasa_relacion_list']=array (
  '' => '',
  0 => 'Accionista',
  1 => 'Cliente',
  2 => 'Cliente Internacional',
  3 => 'Colaborador',
  4 => 'Consumidor',
  6 => 'Contratista',
  8 => 'Proveedor',
  9 => 'Público general',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_activo_falla_c_list.php

 // created: 2016-09-27 01:20:16

$app_list_strings['sasa_activo_falla_c_list']=array (
  '' => '',
  0 => 'No continua como cliente',
  1 => 'Traslado de local',
  3 => 'Se terminó el contrato',
  4 => 'Problemas de servicio',
  5 => 'Otros',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_organizaciondeventas_list.php

 // created: 2016-08-16 15:56:19

$app_list_strings['organizaciondeventas_list']=array (
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipodocumento_list.php

 // created: 2016-08-16 22:50:21

$app_list_strings['sasa_tipodocumento_list']=array (
  0 => '',
  1 => 'Cédula',
  2 => 'Cédula extranjeria',
  4 => 'Pasaporte',
  5 => 'Tarjeta Identidad',
  7 => 'Desconocido',
  8 => 'NIT',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_producto_motivos_list.php

 // created: 2016-09-30 21:06:33

$app_list_strings['sasa_producto_motivos_list']=array (
  '' => '',
  0 => 'Se acabo el producto',
  1 => 'Se incumplió la visita',
  2 => 'Otros',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_barrio_list.php

 // created: 2016-09-05 15:04:13

$app_list_strings['sasa_barrio_list']=array (
  0 => 'ACANTO',
  1 => 'ALCALA',
  2 => 'BOSQUES DE ZUÑIGA',
  310 => 'ANDALUCIA',
  311 => 'GRANIZAL',
  312 => 'LA ALDEA',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipodefalla_c_list.php

 // created: 2016-10-08 01:15:08

$app_list_strings['sasa_tipodefalla_c_list']=array (
  '' => '',
  'Apelmazamiento' => 'Apelmazamiento',
  'Falla billetero' => 'Falla billetero',
  'Falla monedero' => 'Falla monedero',
  'Desconfigurada' => 'Desconfigurada',
  'No dispensa bebidas' => 'No dispensa bebidas',
  'Problemas de temperatura' => 'Problemas de temperatura',
  'Problemas electricos' => 'Problemas electricos',
  'No entrega producto' => 'No entrega producto',
  'Falla bluevending' => 'Falla bluevending',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_ciudad_c_list.php

 // created: 2016-09-05 15:00:27

$app_list_strings['sasa_ciudad_c_list']=array (
  0 => 'ENVIGADO',
  1 => 'MEDELLÍN',
  2 => 'SABANETA',
  19 => 'BARRANQUILLA',
  20 => 'SOLEDAD',
  21 => 'MALAMBO',
  32 => 'BOGOTÁ, D.C.',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.maestro_materiales.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutmm_maestro_materiales'] = 'Maestro materiales';
$app_list_strings['moduleListSingular']['nutmm_maestro_materiales'] = 'Maestro material';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_activo_motivo_c_list.php

 // created: 2016-09-17 17:36:05

$app_list_strings['sasa_activo_motivo_c_list']=array (
  0 => 'Máquina Sucia',
  1 => 'No tiene producto',
  2 => 'Devolución incorrecta',
  3 => 'Otros',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_timezone_dom.php

 // created: 2016-09-10 15:57:10

$app_list_strings['timezone_dom']=array (
  'Africa/Abidjan' => 'Africa/Abidjan',
  'Africa/Accra' => 'Africa/Accra',
  'Africa/Addis_Ababa' => 'Africa/Addis_Ababa',
  'Africa/Algiers' => 'Africa/Algiers',
  'Africa/Asmera' => 'Africa/Asmera',
  'Africa/Bamako' => 'Africa/Bamako',
  'Africa/Bangui' => 'Africa/Bangui',
  'Africa/Banjul' => 'Africa/Banjul',
  'Africa/Bissau' => 'Africa/Bissau',
  'Africa/Blantyre' => 'Africa/Blantyre',
  'Africa/Brazzaville' => 'Africa/Brazzaville',
  'Africa/Bujumbura' => 'Africa/Bujumbura',
  'Africa/Cairo' => 'Africa/Cairo',
  'Africa/Casablanca' => 'Africa/Casablanca',
  'Africa/Ceuta' => 'Africa/Ceuta',
  'Africa/Conakry' => 'Africa/Conakry',
  'Africa/Dakar' => 'Africa/Dakar',
  'Africa/Dar_es_Salaam' => 'Africa/Dar_es_Salaam',
  'Africa/Djibouti' => 'Africa/Djibouti',
  'Africa/Douala' => 'Africa/Douala',
  'Africa/El_Aaiun' => 'Africa/El_Aaiun',
  'Africa/Freetown' => 'Africa/Freetown',
  'Africa/Gaborone' => 'Africa/Gaborone',
  'Africa/Harare' => 'Africa/Harare',
  'Africa/Johannesburg' => 'Africa/Johannesburg',
  'Africa/Kampala' => 'Africa/Kampala',
  'Africa/Khartoum' => 'Africa/Khartoum',
  'Africa/Kigali' => 'Africa/Kigali',
  'Africa/Kinshasa' => 'Africa/Kinshasa',
  'Africa/Lagos' => 'Africa/Lagos',
  'Africa/Libreville' => 'Africa/Libreville',
  'Africa/Lome' => 'Africa/Lome',
  'Africa/Luanda' => 'Africa/Luanda',
  'Africa/Lubumbashi' => 'Africa/Lubumbashi',
  'Africa/Lusaka' => 'Africa/Lusaka',
  'Africa/Malabo' => 'Africa/Malabo',
  'Africa/Maputo' => 'Africa/Maputo',
  'Africa/Maseru' => 'Africa/Maseru',
  'Africa/Mbabane' => 'Africa/Mbabane',
  'Africa/Mogadishu' => 'Africa/Mogadishu',
  'Africa/Monrovia' => 'Africa/Monrovia',
  'Africa/Nairobi' => 'Africa/Nairobi',
  'Africa/Ndjamena' => 'Africa/Ndjamena',
  'Africa/Niamey' => 'Africa/Niamey',
  'Africa/Nouakchott' => 'Africa/Nouakchott',
  'Africa/Ouagadougou' => 'Africa/Ouagadougou',
  'Africa/Porto-Novo' => 'Africa/Porto-Novo',
  'Africa/Sao_Tome' => 'Africa/Sao_Tome',
  'Africa/Tripoli' => 'Africa/Tripoli',
  'Africa/Tunis' => 'Africa/Tunis',
  'Africa/Windhoek' => 'Africa/Windhoek',
  'America/Adak' => 'America/Adak',
  'America/Anchorage' => 'America/Anchorage',
  'America/Anguilla' => 'America/Anguilla',
  'America/Antigua' => 'America/Antigua',
  'America/Araguaina' => 'America/Araguaina',
  'America/Argentina/Buenos_Aires' => 'America/Argentina/Buenos_Aires',
  'America/Argentina/Catamarca' => 'America/Argentina/Catamarca',
  'America/Argentina/Cordoba' => 'America/Argentina/Cordoba',
  'America/Argentina/Jujuy' => 'America/Argentina/Jujuy',
  'America/Argentina/La_Rioja' => 'America/Argentina/La_Rioja',
  'America/Argentina/Mendoza' => 'America/Argentina/Mendoza',
  'America/Argentina/Rio_Gallegos' => 'America/Argentina/Rio_Gallegos',
  'America/Argentina/San_Juan' => 'America/Argentina/San_Juan',
  'America/Argentina/Tucuman' => 'America/Argentina/Tucuman',
  'America/Argentina/Ushuaia' => 'America/Argentina/Ushuaia',
  'America/Aruba' => 'America/Aruba',
  'America/Asuncion' => 'America/Asuncion',
  'America/Bahia' => 'America/Bahia',
  'America/Barbados' => 'America/Barbados',
  'America/Belem' => 'America/Belem',
  'America/Belize' => 'America/Belize',
  'America/Boa_Vista' => 'America/Boa_Vista',
  'America/Bogota' => 'America/Bogota',
  'America/Boise' => 'America/Boise',
  'America/Cambridge_Bay' => 'America/Cambridge_Bay',
  'America/Campo_Grande' => 'America/Campo_Grande',
  'America/Cancun' => 'America/Cancun',
  'America/Caracas' => 'America/Caracas',
  'America/Cayenne' => 'America/Cayenne',
  'America/Cayman' => 'America/Cayman',
  'America/Chicago' => 'America/Chicago',
  'America/Chihuahua' => 'America/Chihuahua',
  'America/Coral_Harbour' => 'America/Coral_Harbour',
  'America/Costa_Rica' => 'America/Costa_Rica',
  'America/Cuiaba' => 'America/Cuiaba',
  'America/Curacao' => 'America/Curacao',
  'America/Danmarkshavn' => 'America/Danmarkshavn',
  'America/Dawson' => 'America/Dawson',
  'America/Dawson_Creek' => 'America/Dawson_Creek',
  'America/Denver' => 'America/Denver',
  'America/Detroit' => 'America/Detroit',
  'America/Dominica' => 'America/Dominica',
  'America/Edmonton' => 'America/Edmonton',
  'America/Eirunepe' => 'America/Eirunepe',
  'America/El_Salvador' => 'America/El_Salvador',
  'America/Fortaleza' => 'America/Fortaleza',
  'America/Glace_Bay' => 'America/Glace_Bay',
  'America/Godthab' => 'America/Godthab',
  'America/Goose_Bay' => 'America/Goose_Bay',
  'America/Grand_Turk' => 'America/Grand_Turk',
  'America/Grenada' => 'America/Grenada',
  'America/Guadeloupe' => 'America/Guadeloupe',
  'America/Guatemala' => 'America/Guatemala',
  'America/Guayaquil' => 'America/Guayaquil',
  'America/Guyana' => 'America/Guyana',
  'America/Halifax' => 'America/Halifax',
  'America/Havana' => 'America/Havana',
  'America/Hermosillo' => 'America/Hermosillo',
  'America/Indiana/Indianapolis' => 'America/Indiana/Indianapolis',
  'America/Indiana/Knox' => 'America/Indiana/Knox',
  'America/Indiana/Marengo' => 'America/Indiana/Marengo',
  'America/Indiana/Vevay' => 'America/Indiana/Vevay',
  'America/Inuvik' => 'America/Inuvik',
  'America/Iqaluit' => 'America/Iqaluit',
  'America/Jamaica' => 'America/Jamaica',
  'America/Juneau' => 'America/Juneau',
  'America/Kentucky/Louisville' => 'America/Kentucky/Louisville',
  'America/Kentucky/Monticello' => 'America/Kentucky/Monticello',
  'America/La_Paz' => 'America/La_Paz',
  'America/Lima' => 'America/Lima',
  'America/Los_Angeles' => 'America/Los_Angeles',
  'America/Maceio' => 'America/Maceio',
  'America/Managua' => 'America/Managua',
  'America/Manaus' => 'America/Manaus',
  'America/Martinique' => 'America/Martinique',
  'America/Mazatlan' => 'America/Mazatlan',
  'America/Menominee' => 'America/Menominee',
  'America/Merida' => 'America/Merida',
  'America/Mexico_City' => 'America/Mexico_City',
  'America/Miquelon' => 'America/Miquelon',
  'America/Monterrey' => 'America/Monterrey',
  'America/Montevideo' => 'America/Montevideo',
  'America/Montreal' => 'America/Montreal',
  'America/Montserrat' => 'America/Montserrat',
  'America/Nassau' => 'America/Nassau',
  'America/New_York' => 'America/New_York',
  'America/Nipigon' => 'America/Nipigon',
  'America/Nome' => 'America/Nome',
  'America/Noronha' => 'America/Noronha',
  'America/North_Dakota/Center' => 'America/North_Dakota/Center',
  'America/Panama' => 'America/Panama',
  'America/Pangnirtung' => 'America/Pangnirtung',
  'America/Paramaribo' => 'America/Paramaribo',
  'America/Phoenix' => 'America/Phoenix',
  'America/Port-au-Prince' => 'America/Port-au-Prince',
  'America/Port_of_Spain' => 'America/Port_of_Spain',
  'America/Porto_Velho' => 'America/Porto_Velho',
  'America/Puerto_Rico' => 'America/Puerto_Rico',
  'America/Rainy_River' => 'America/Rainy_River',
  'America/Rankin_Inlet' => 'America/Rankin_Inlet',
  'America/Recife' => 'America/Recife',
  'America/Regina' => 'America/Regina',
  'America/Rio_Branco' => 'America/Rio_Branco',
  'America/Santiago' => 'America/Santiago',
  'America/Santo_Domingo' => 'America/Santo_Domingo',
  'America/Sao_Paulo' => 'America/Sao_Paulo',
  'America/Scoresbysund' => 'America/Scoresbysund',
  'America/St_Johns' => 'America/St_Johns',
  'America/St_Kitts' => 'America/St_Kitts',
  'America/St_Lucia' => 'America/St_Lucia',
  'America/St_Thomas' => 'America/St_Thomas',
  'America/St_Vincent' => 'America/St_Vincent',
  'America/Swift_Current' => 'America/Swift_Current',
  'America/Tegucigalpa' => 'America/Tegucigalpa',
  'America/Thule' => 'America/Thule',
  'America/Thunder_Bay' => 'America/Thunder_Bay',
  'America/Tijuana' => 'America/Tijuana',
  'America/Toronto' => 'America/Toronto',
  'America/Tortola' => 'America/Tortola',
  'America/Vancouver' => 'America/Vancouver',
  'America/Whitehorse' => 'America/Whitehorse',
  'America/Winnipeg' => 'America/Winnipeg',
  'America/Yakutat' => 'America/Yakutat',
  'America/Yellowknife' => 'America/Yellowknife',
  'Antarctica/Casey' => 'Antarctica/Casey',
  'Antarctica/Davis' => 'Antarctica/Davis',
  'Antarctica/DumontDUrville' => 'Antarctica/DumontDUrville',
  'Antarctica/Mawson' => 'Antarctica/Mawson',
  'Antarctica/McMurdo' => 'Antarctica/McMurdo',
  'Antarctica/Palmer' => 'Antarctica/Palmer',
  'Antarctica/Rothera' => 'Antarctica/Rothera',
  'Antarctica/Syowa' => 'Antarctica/Syowa',
  'Antarctica/Vostok' => 'Antarctica/Vostok',
  'Asia/Aden' => 'Asia/Aden',
  'Asia/Almaty' => 'Asia/Almaty',
  'Asia/Amman' => 'Asia/Amman',
  'Asia/Anadyr' => 'Asia/Anadyr',
  'Asia/Aqtau' => 'Asia/Aqtau',
  'Asia/Aqtobe' => 'Asia/Aqtobe',
  'Asia/Ashgabat' => 'Asia/Ashgabat',
  'Asia/Baghdad' => 'Asia/Baghdad',
  'Asia/Bahrain' => 'Asia/Bahrain',
  'Asia/Baku' => 'Asia/Baku',
  'Asia/Bangkok' => 'Asia/Bangkok',
  'Asia/Beijing' => 'Asia/Beijing',
  'Asia/Beirut' => 'Asia/Beirut',
  'Asia/Bishkek' => 'Asia/Bishkek',
  'Asia/Brunei' => 'Asia/Brunei',
  'Asia/Calcutta' => 'Asia/Calcutta',
  'Asia/Choibalsan' => 'Asia/Choibalsan',
  'Asia/Chongqing' => 'Asia/Chongqing',
  'Asia/Colombo' => 'Asia/Colombo',
  'Asia/Damascus' => 'Asia/Damascus',
  'Asia/Dhaka' => 'Asia/Dhaka',
  'Asia/Dili' => 'Asia/Dili',
  'Asia/Dubai' => 'Asia/Dubai',
  'Asia/Dushanbe' => 'Asia/Dushanbe',
  'Asia/Gaza' => 'Asia/Gaza',
  'Asia/Harbin' => 'Asia/Harbin',
  'Asia/Hong_Kong' => 'Asia/Hong_Kong',
  'Asia/Hovd' => 'Asia/Hovd',
  'Asia/Irkutsk' => 'Asia/Irkutsk',
  'Asia/Jakarta' => 'Asia/Jakarta',
  'Asia/Jayapura' => 'Asia/Jayapura',
  'Asia/Jerusalem' => 'Asia/Jerusalem',
  'Asia/Kabul' => 'Asia/Kabul',
  'Asia/Kamchatka' => 'Asia/Kamchatka',
  'Asia/Karachi' => 'Asia/Karachi',
  'Asia/Kashgar' => 'Asia/Kashgar',
  'Asia/Katmandu' => 'Asia/Katmandu',
  'Asia/Krasnoyarsk' => 'Asia/Krasnoyarsk',
  'Asia/Kuala_Lumpur' => 'Asia/Kuala_Lumpur',
  'Asia/Kuching' => 'Asia/Kuching',
  'Asia/Kuwait' => 'Asia/Kuwait',
  'Asia/Macau' => 'Asia/Macau',
  'Asia/Magadan' => 'Asia/Magadan',
  'Asia/Makassar' => 'Asia/Makassar',
  'Asia/Manila' => 'Asia/Manila',
  'Asia/Muscat' => 'Asia/Muscat',
  'Asia/Nicosia' => 'Asia/Nicosia',
  'Asia/Novosibirsk' => 'Asia/Novosibirsk',
  'Asia/Omsk' => 'Asia/Omsk',
  'Asia/Oral' => 'Asia/Oral',
  'Asia/Phnom_Penh' => 'Asia/Phnom_Penh',
  'Asia/Pontianak' => 'Asia/Pontianak',
  'Asia/Pyongyang' => 'Asia/Pyongyang',
  'Asia/Qatar' => 'Asia/Qatar',
  'Asia/Qyzylorda' => 'Asia/Qyzylorda',
  'Asia/Rangoon' => 'Asia/Rangoon',
  'Asia/Riyadh' => 'Asia/Riyadh',
  'Asia/Saigon' => 'Asia/Saigon',
  'Asia/Sakhalin' => 'Asia/Sakhalin',
  'Asia/Samarkand' => 'Asia/Samarkand',
  'Asia/Seoul' => 'Asia/Seoul',
  'Asia/Shanghai' => 'Asia/Shanghai',
  'Asia/Singapore' => 'Asia/Singapore',
  'Asia/Taipei' => 'Asia/Taipei',
  'Asia/Tashkent' => 'Asia/Tashkent',
  'Asia/Tbilisi' => 'Asia/Tbilisi',
  'Asia/Tehran' => 'Asia/Tehran',
  'Asia/Thimphu' => 'Asia/Thimphu',
  'Asia/Tokyo' => 'Asia/Tokyo',
  'Asia/Ulaanbaatar' => 'Asia/Ulaanbaatar',
  'Asia/Urumqi' => 'Asia/Urumqi',
  'Asia/Vientiane' => 'Asia/Vientiane',
  'Asia/Vladivostok' => 'Asia/Vladivostok',
  'Asia/Yakutsk' => 'Asia/Yakutsk',
  'Asia/Yekaterinburg' => 'Asia/Yekaterinburg',
  'Asia/Yerevan' => 'Asia/Yerevan',
  'Atlantic/Azores' => 'Atlantic/Azores',
  'Atlantic/Bermuda' => 'Atlantic/Bermuda',
  'Atlantic/Canary' => 'Atlantic/Canary',
  'Atlantic/Cape_Verde' => 'Atlantic/Cape_Verde',
  'Atlantic/Faeroe' => 'Atlantic/Faeroe',
  'Atlantic/Madeira' => 'Atlantic/Madeira',
  'Atlantic/Reykjavik' => 'Atlantic/Reykjavik',
  'Atlantic/South_Georgia' => 'Atlantic/South_Georgia',
  'Atlantic/St_Helena' => 'Atlantic/St_Helena',
  'Atlantic/Stanley' => 'Atlantic/Stanley',
  'Australia/Adelaide' => 'Australia/Adelaide',
  'Australia/Brisbane' => 'Australia/Brisbane',
  'Australia/Broken_Hill' => 'Australia/Broken_Hill',
  'Australia/Currie' => 'Australia/Currie',
  'Australia/Darwin' => 'Australia/Darwin',
  'Australia/Hobart' => 'Australia/Hobart',
  'Australia/Lindeman' => 'Australia/Lindeman',
  'Australia/Melbourne' => 'Australia/Melbourne',
  'Australia/Perth' => 'Australia/Perth',
  'Australia/Sydney' => 'Australia/Sydney',
  'CET' => 'CET',
  'EET' => 'EET',
  'Europe/Copenhagen' => 'Europa y Copenhague',
  'Europe/Amsterdam' => 'Europa/Amsterdam',
  'Europe/Athens' => 'Europa/Atenas',
  'Europe/Berlin' => 'Europa/Berlín',
  'Europe/Brussels' => 'Europa/Bruselas',
  'Europe/Bucharest' => 'Europa/Bucarest',
  'Europe/Budapest' => 'Europa/Budapest',
  'Europe/Chisinau' => 'Europa/Chisinau',
  'Europe/Gibraltar' => 'Europa/Gibraltar',
  'Europe/Helsinki' => 'Europa/Helsinki',
  'Europe/Kaliningrad' => 'Europa/Kaliningrado',
  'Europe/Lisbon' => 'Europa/Lisboa',
  'Europe/Luxembourg' => 'Europa/Luxemburgo',
  'Europe/Malta' => 'Europa/Malta',
  'Europe/Moscow' => 'Europa/Moscú',
  'Europe/Monaco' => 'Europa/Mónaco',
  'Europe/Oslo' => 'Europa/Oslo',
  'Europe/Paris' => 'Europa/París',
  'Europe/Prague' => 'Europa/Praga',
  'Europe/Riga' => 'Europa/Riga',
  'Europe/Rome' => 'Europa/Roma',
  'Europe/Samara' => 'Europa/Samara',
  'Europe/Sofia' => 'Europa/Sofia',
  'Europe/Tallinn' => 'Europa/Tallin',
  'Europe/Vaduz' => 'Europa/Vaduz',
  'Europe/Warsaw' => 'Europa/Varsovia',
  'Europe/Vilnius' => 'Europa/Vilnius',
  'Europe/Andorra' => 'Europe/Andorra',
  'Europe/Belgrade' => 'Europe/Belgrade',
  'Europe/Dublin' => 'Europe/Dublin',
  'Europe/Istanbul' => 'Europe/Istanbul',
  'Europe/Kiev' => 'Europe/Kiev',
  'Europe/London' => 'Europe/London',
  'Europe/Madrid' => 'Europe/Madrid',
  'Europe/Minsk' => 'Europe/Minsk',
  'Europe/Simferopol' => 'Europe/Simferopol',
  'Europe/Stockholm' => 'Europe/Stockholm',
  'Europe/Tirane' => 'Europe/Tirane',
  'Europe/Uzhgorod' => 'Europe/Uzhgorod',
  'Europe/Vienna' => 'Europe/Vienna',
  'Europe/Zaporozhye' => 'Europe/Zaporozhye',
  'Europe/Zurich' => 'Europe/Zurich',
  'Indian/Antananarivo' => 'Indian/Antananarivo',
  'Indian/Chagos' => 'Indian/Chagos',
  'Indian/Christmas' => 'Indian/Christmas',
  'Indian/Cocos' => 'Indian/Cocos',
  'Indian/Comoro' => 'Indian/Comoro',
  'Indian/Kerguelen' => 'Indian/Kerguelen',
  'Indian/Mahe' => 'Indian/Mahe',
  'Indian/Maldives' => 'Indian/Maldives',
  'Indian/Mauritius' => 'Indian/Mauritius',
  'Indian/Mayotte' => 'Indian/Mayotte',
  'Indian/Reunion' => 'Indian/Reunion',
  'MET' => 'MET',
  'Pacific/Apia' => 'Pacific/Apia',
  'Pacific/Auckland' => 'Pacific/Auckland',
  'Pacific/Chatham' => 'Pacific/Chatham',
  'Pacific/Easter' => 'Pacific/Easter',
  'Pacific/Efate' => 'Pacific/Efate',
  'Pacific/Enderbury' => 'Pacific/Enderbury',
  'Pacific/Fakaofo' => 'Pacific/Fakaofo',
  'Pacific/Fiji' => 'Pacific/Fiji',
  'Pacific/Funafuti' => 'Pacific/Funafuti',
  'Pacific/Galapagos' => 'Pacific/Galapagos',
  'Pacific/Gambier' => 'Pacific/Gambier',
  'Pacific/Guadalcanal' => 'Pacific/Guadalcanal',
  'Pacific/Guam' => 'Pacific/Guam',
  'Pacific/Honolulu' => 'Pacific/Honolulu',
  'Pacific/Johnston' => 'Pacific/Johnston',
  'Pacific/Kiritimati' => 'Pacific/Kiritimati',
  'Pacific/Kosrae' => 'Pacific/Kosrae',
  'Pacific/Kwajalein' => 'Pacific/Kwajalein',
  'Pacific/Majuro' => 'Pacific/Majuro',
  'Pacific/Marquesas' => 'Pacific/Marquesas',
  'Pacific/Midway' => 'Pacific/Midway',
  'Pacific/Nauru' => 'Pacific/Nauru',
  'Pacific/Niue' => 'Pacific/Niue',
  'Pacific/Norfolk' => 'Pacific/Norfolk',
  'Pacific/Noumea' => 'Pacific/Noumea',
  'Pacific/Pago_Pago' => 'Pacific/Pago_Pago',
  'Pacific/Palau' => 'Pacific/Palau',
  'Pacific/Pitcairn' => 'Pacific/Pitcairn',
  'Pacific/Ponape' => 'Pacific/Ponape',
  'Pacific/Port_Moresby' => 'Pacific/Port_Moresby',
  'Pacific/Rarotonga' => 'Pacific/Rarotonga',
  'Pacific/Saipan' => 'Pacific/Saipan',
  'Pacific/Tahiti' => 'Pacific/Tahiti',
  'Pacific/Tarawa' => 'Pacific/Tarawa',
  'Pacific/Tongatapu' => 'Pacific/Tongatapu',
  'Pacific/Truk' => 'Pacific/Truk',
  'Pacific/Wake' => 'Pacific/Wake',
  'Pacific/Wallis' => 'Pacific/Wallis',
  'WET' => 'WET',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_account_type_list.php

 // created: 2016-09-02 15:35:07

$app_list_strings['account_type_list']=array (
  '' => '',
  'accionista' => 'Accionista',
  'colaborador' => 'Colaborador',
  'cliente' => 'Cliente',
  'proveedor' => 'Proveedor',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_case_status_dom.php

 // created: 2016-09-27 00:31:23

$app_list_strings['case_status_dom']=array (
  'New' => 'Nuevo',
  'Assigned' => 'Asignado',
  'Closed' => 'Cerrado',
  'Pending Input' => 'Pendiente de Información',
  'Rejected' => 'Rechazado',
  'Duplicate' => 'Duplicar',
  'Clasificado' => 'Clasificado',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_producto_muestra_c_list.php

 // created: 2016-09-06 23:22:18

$app_list_strings['sasa_producto_muestra_c_list']=array (
  '' => '',
  0 => 'Si',
  1 => 'No',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_syno_roles_list.php

 // created: 2016-10-24 21:42:43

$app_list_strings['syno_roles_list']=array (
  '60609594-6e28-11e6-8e0c-027a430c0995' => 'Coordinadores CIC',
  '842544ec-5f01-11e6-82bb-027a430c0995' => 'Customer Self-Service Portal Role',
  '31ca9ec3-e8a1-b926-3198-577467c957f6' => 'Customer Support Administrator',
  'efbb520c-76c1-ae63-c19f-577467d56c28' => 'Marketing Administrator',
  '80b6443a-8762-11e6-9289-02a6691319f3' => 'NO Admin CIC',
  'bc0fe950-858c-11e6-b331-060b37ffb723' => 'NO Red de Servicios',
  '572e0f92-8679-11e6-ace4-06d48441b777' => 'NO VP Agentes',
  '46e59ce0-8679-11e6-8448-06d48441b777' => 'NO VP Backoffice',
  '1c471e1c-8595-11e6-b400-027a430c0995' => 'NO VP Coordinador Lider Call Center',
  'ff008b3e-8591-11e6-9fff-06d48441b777' => 'NO VP Red de Servicios Avanzado',
  '2c1e6c6a-8715-11e6-83ab-06d48441b777' => 'PZ Admin CIC',
  '1e91078a-8713-11e6-ab23-027a430c0995' => 'PZ Red de Servicios',
  '6e3e9b8e-6e28-11e6-bcf1-027a430c0995' => 'Rol 3',
  '75b4a66a-6e28-11e6-b0b9-027a430c0995' => 'Rol 4',
  '676cc204-6e28-11e6-8dcb-027a430c0995' => 'Rol base (NO BORRAR)',
  'b4d49231-4904-df0f-d2d1-577467e1e14b' => 'Sales Administrator',
  '03052a8c-89b6-11e6-9881-06b20b8677ed' => 'SN Admin CIC',
  'dfc202f6-89b1-11e6-af6c-06d48441b777' => 'SN Agentes',
  'c72ddfbc-9a32-11e6-9ddb-02a6691319f3' => 'SN Backoffice',
  '66b33dac-89b2-11e6-8910-06b20b8677ed' => 'SN Red de Servicios',
  '41d97258-89b2-11e6-b73d-060b37ffb723' => 'SN Red de Servicios Avanzado',
  '16fddb0b-4e77-9716-50b8-57746786eff2' => 'Tracker',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.maestro_clientes.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutmc_nutmc_clientes'] = 'Maestro clientes';
$app_list_strings['moduleListSingular']['nutmc_nutmc_clientes'] = 'Maestro cliente';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_motivo_list.php

 // created: 2016-11-02 00:05:55

$app_list_strings['sasa_motivo_list']=array (
  '' => '',
  0 => 'Contacto No Efectivo',
  1 => 'Felicitación/Agradecimiento',
  2 => 'Información',
  3 => 'Queja',
  4 => 'Solicitud',
  5 => 'Sugerencias',
  6 => 'Estado de la solicitud',
  8 => 'Pendiente por Clasificar',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_multiple_respuesta_c_list.php

 // created: 2016-09-02 15:33:06

$app_list_strings['sasa_multiple_respuesta_c_list']=array (
  0 => 'Pendón',
  1 => 'Brochure',
  2 => 'Muestras gratis',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_organizacion_ventas_list.php

 // created: 2016-09-07 15:26:54

$app_list_strings['sasa_organizacion_ventas_list']=array (
  'AF10' => 'AF10',
  'AF20' => 'AF20',
  'AH10' => 'AH10',
  'AH20' => 'AH20',
  'AL10' => 'AL10',
  'AL20' => 'AL20',
  'BR10' => 'BR10',
  'BR20' => 'BR20',
  'BS10' => 'BS10',
  'BS20' => 'BS20',
  'CC10' => 'CC10',
  'CC20' => 'CC20',
  'CM10' => 'CM10',
  'CM20' => 'CM20',
  'CN10' => 'CN10',
  'CN20' => 'CN20',
  'CO10' => 'CO10',
  'CO1I' => 'CO1I',
  'CR10' => 'CR10',
  'CR20' => 'CR20',
  'DP10' => 'DP10',
  'DP20' => 'DP20',
  'DR10' => 'DR10',
  'DR20' => 'DR20',
  'DU10' => 'DU10',
  'DU20' => 'DU20',
  'EC10' => 'EC10',
  'EC20' => 'EC20',
  'FF10' => 'FF10',
  'FF20' => 'FF20',
  'FI10' => 'FI10',
  'FI20' => 'FI20',
  'FP10' => 'FP10',
  'FP20' => 'FP20',
  'GC10' => 'GC10',
  'GC20' => 'GC20',
  'GN10' => 'GN10',
  'GN20' => 'GN20',
  'GZ10' => 'GZ10',
  'GZ20' => 'GZ20',
  'HB10' => 'HB10',
  'HB20' => 'HB20',
  'HV10' => 'HV10',
  'HV20' => 'HV20',
  'IA10' => 'IA10',
  'IA20' => 'IA20',
  'IZ10' => 'IZ10',
  'IZ20' => 'IZ20',
  'LN10' => 'LN10',
  'LN20' => 'LN20',
  'LR10' => 'LR10',
  'LT10' => 'LT10',
  'LT20' => 'LT20',
  'ML10' => 'ML10',
  'ML1I' => 'ML1I',
  'ML20' => 'ML20',
  'MS10' => 'MS10',
  'MS20' => 'MS20',
  'NN10' => 'NN10',
  'NN1I' => 'NN1I',
  'NN20' => 'NN20',
  'NO10' => 'NO10',
  'NU10' => 'NU10',
  'NU20' => 'NU20',
  'OC10' => 'OC10',
  'OC20' => 'OC20',
  'PA10' => 'PA10',
  'PN10' => 'PN10',
  'PN20' => 'PN20',
  'PP10' => 'PP10',
  'PP20' => 'PP20',
  'PZ10' => 'PZ10',
  'PZ20' => 'PZ20',
  'SC10' => 'SC10',
  'SC20' => 'SC20',
  'SR10' => 'SR10',
  'SS10' => 'SS10',
  'SS20' => 'SS20',
  'UC10' => 'UC10',
  'UC20' => 'UC20',
  'VD10' => 'VD10',
  'VD20' => 'VD20',
  'NO20' => 'NO20',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sociedades.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nuts_sociedad'] = 'Sociedades';
$app_list_strings['moduleListSingular']['nuts_sociedad'] = 'Sociedad';
$app_list_strings['countries_dom']['ABU DHABI'] = 'ABU DHABI';
$app_list_strings['countries_dom']['ADEN'] = 'ADEN';
$app_list_strings['countries_dom']['AFGHANISTAN'] = 'AFGANISTÁN';
$app_list_strings['countries_dom']['ALBANIA'] = 'ALBANIA';
$app_list_strings['countries_dom']['ALGERIA'] = 'ARGELIA';
$app_list_strings['countries_dom']['AMERICAN SAMOA'] = 'SAMOA AMERICANA';
$app_list_strings['countries_dom']['ANDORRA'] = 'ANDORRA';
$app_list_strings['countries_dom']['ANGOLA'] = 'ANGOLA';
$app_list_strings['countries_dom']['ANTARCTICA'] = 'ANTÁRTIDA';
$app_list_strings['countries_dom']['ANTIGUA'] = 'ANTIGUA';
$app_list_strings['countries_dom']['ARGENTINA'] = 'ARGENTINA';
$app_list_strings['countries_dom']['ARMENIA'] = 'ARMENIA';
$app_list_strings['countries_dom']['ARUBA'] = 'ARUBA';
$app_list_strings['countries_dom']['AUSTRALIA'] = 'AUSTRALIA';
$app_list_strings['countries_dom']['AUSTRIA'] = 'AUSTRIA';
$app_list_strings['countries_dom']['AZERBAIJAN'] = 'AZERBAIYÁN';
$app_list_strings['countries_dom']['BAHAMAS'] = 'BAHAMAS';
$app_list_strings['countries_dom']['BAHRAIN'] = 'BAHRAIN';
$app_list_strings['countries_dom']['BANGLADESH'] = 'BANGLADÉS';
$app_list_strings['countries_dom']['BARBADOS'] = 'BARBADOS';
$app_list_strings['countries_dom']['BELARUS'] = 'BIELORRUSIA';
$app_list_strings['countries_dom']['BELGIUM'] = 'BÉLGICA';
$app_list_strings['countries_dom']['BELIZE'] = 'BELICE';
$app_list_strings['countries_dom']['BENIN'] = 'BENIN';
$app_list_strings['countries_dom']['BERMUDA'] = 'BERMUDA';
$app_list_strings['countries_dom']['BHUTAN'] = 'BUTÁN';
$app_list_strings['countries_dom']['BOLIVIA'] = 'BOLIVIA';
$app_list_strings['countries_dom']['BOSNIA'] = 'BOSNIA';
$app_list_strings['countries_dom']['BOTSWANA'] = 'BOTSUANA';
$app_list_strings['countries_dom']['BOUVET ISLAND'] = 'ISLA BOUVET';
$app_list_strings['countries_dom']['BRAZIL'] = 'BRASIL';
$app_list_strings['countries_dom']['BRITISH ANTARCTICA TERRITORY'] = 'TERRITORIO BRITÁNICO EN LA ANTÁRTIDA';
$app_list_strings['countries_dom']['BRITISH INDIAN OCEAN TERRITORY'] = 'TERRITORIO BRITÁNICO DEL OCÉANO ÍNDICO';
$app_list_strings['countries_dom']['BRITISH VIRGIN ISLANDS'] = 'ISLAS VÍRGENES BRITÁNICAS';
$app_list_strings['countries_dom']['BRITISH WEST INDIES'] = 'BRITISH WEST INDIES';
$app_list_strings['countries_dom']['BRUNEI'] = 'BRUNEI';
$app_list_strings['countries_dom']['BULGARIA'] = 'BULGARIA';
$app_list_strings['countries_dom']['BURKINA FASO'] = 'BURKINA FASO';
$app_list_strings['countries_dom']['BURUNDI'] = 'BURUNDI';
$app_list_strings['countries_dom']['CAMBODIA'] = 'CAMBOYA';
$app_list_strings['countries_dom']['CAMEROON'] = 'CAMERÚN';
$app_list_strings['countries_dom']['CANADA'] = 'CANADÁ';
$app_list_strings['countries_dom']['CANAL ZONE'] = 'ZONA DEL CANAL';
$app_list_strings['countries_dom']['CANARY ISLAND'] = 'ISLAS CANARIAS';
$app_list_strings['countries_dom']['CAPE VERDI ISLANDS'] = 'ISLAS DE CABO VERDE';
$app_list_strings['countries_dom']['CAYMAN ISLANDS'] = 'ISLAS CAIMÁN';
$app_list_strings['countries_dom']['CEVLON'] = 'CEVLON';
$app_list_strings['countries_dom']['CHAD'] = 'CHAD';
$app_list_strings['countries_dom']['CHANNEL ISLAND UK'] = 'ISLAS DEL CANAL REINO UNIDO';
$app_list_strings['countries_dom']['CHILE'] = 'CHILE';
$app_list_strings['countries_dom']['CHINA'] = 'CHINA';
$app_list_strings['countries_dom']['CHRISTMAS ISLAND'] = 'ISLA DE NAVIDAD';
$app_list_strings['countries_dom']['COCOS (KEELING) ISLAND'] = 'ISLAS COCOS (KEELING)';
$app_list_strings['countries_dom']['COLOMBIA'] = 'COLOMBIA';
$app_list_strings['countries_dom']['COMORO ISLANDS'] = 'ISLAS COMORO';
$app_list_strings['countries_dom']['CONGO'] = 'CONGO';
$app_list_strings['countries_dom']['CONGO KINSHASA'] = 'CONGO KINSHASA';
$app_list_strings['countries_dom']['COOK ISLANDS'] = 'ISLAS COOK';
$app_list_strings['countries_dom']['COSTA RICA'] = 'COSTA RICA';
$app_list_strings['countries_dom']['CROATIA'] = 'CROACIA';
$app_list_strings['countries_dom']['CUBA'] = 'CUBA';
$app_list_strings['countries_dom']['CURACAO'] = 'CURACAO';
$app_list_strings['countries_dom']['CYPRUS'] = 'CHIPRE';
$app_list_strings['countries_dom']['CZECH REPUBLIC'] = 'REPÚBLICA CHECA';
$app_list_strings['countries_dom']['DAHOMEY'] = 'DAHOMEY';
$app_list_strings['countries_dom']['DENMARK'] = 'DINAMARCA';
$app_list_strings['countries_dom']['DJIBOUTI'] = 'YIBUTI';
$app_list_strings['countries_dom']['DOMINICA'] = 'DOMINICA';
$app_list_strings['countries_dom']['DOMINICAN REPUBLIC'] = 'REPÚBLICA DOMINICANA';
$app_list_strings['countries_dom']['DUBAI'] = 'DUBAI';
$app_list_strings['countries_dom']['ECUADOR'] = 'ECUADOR';
$app_list_strings['countries_dom']['EGYPT'] = 'EGIPTO';
$app_list_strings['countries_dom']['EL SALVADOR'] = 'EL SALVADOR';
$app_list_strings['countries_dom']['EQUATORIAL GUINEA'] = 'GUINEA ECUATORIAL';
$app_list_strings['countries_dom']['ESTONIA'] = 'ESTONIA';
$app_list_strings['countries_dom']['ETHIOPIA'] = 'ETIOPÍA';
$app_list_strings['countries_dom']['FAEROE ISLANDS'] = 'ISLAS FEROE';
$app_list_strings['countries_dom']['FALKLAND ISLANDS'] = 'ISLAS MALVINAS';
$app_list_strings['countries_dom']['FIJI'] = 'FIJI';
$app_list_strings['countries_dom']['FINLAND'] = 'FINLANDIA';
$app_list_strings['countries_dom']['FRANCE'] = 'FRANCIA';
$app_list_strings['countries_dom']['FRENCH GUIANA'] = 'GUAYANA FRANCESA';
$app_list_strings['countries_dom']['FRENCH POLYNESIA'] = 'POLINESIA FRANCESA';
$app_list_strings['countries_dom']['GABON'] = 'GABÓN';
$app_list_strings['countries_dom']['GAMBIA'] = 'GAMBIA';
$app_list_strings['countries_dom']['GEORGIA'] = 'GEORGIA';
$app_list_strings['countries_dom']['GERMANY'] = 'ALEMANIA';
$app_list_strings['countries_dom']['GHANA'] = 'GHANA';
$app_list_strings['countries_dom']['GIBRALTAR'] = 'GIBRALTAR';
$app_list_strings['countries_dom']['GREECE'] = 'GRECIA';
$app_list_strings['countries_dom']['GREENLAND'] = 'GROENLANDIA';
$app_list_strings['countries_dom']['GUADELOUPE'] = 'GUADALUPE';
$app_list_strings['countries_dom']['GUAM'] = 'GUAM';
$app_list_strings['countries_dom']['GUATEMALA'] = 'GUATEMALA';
$app_list_strings['countries_dom']['GUINEA'] = 'GUINEA';
$app_list_strings['countries_dom']['GUYANA'] = 'GUYANA';
$app_list_strings['countries_dom']['HAITI'] = 'HAITÍ';
$app_list_strings['countries_dom']['HONDURAS'] = 'HONDURAS';
$app_list_strings['countries_dom']['HONG KONG'] = 'HONG KONG';
$app_list_strings['countries_dom']['HUNGARY'] = 'HUNGRÍA';
$app_list_strings['countries_dom']['ICELAND'] = 'ISLANDIA';
$app_list_strings['countries_dom']['IFNI'] = 'IFNI';
$app_list_strings['countries_dom']['INDIA'] = 'INDIA';
$app_list_strings['countries_dom']['INDONESIA'] = 'INDONESIA';
$app_list_strings['countries_dom']['IRAN'] = 'IRÁN';
$app_list_strings['countries_dom']['IRAQ'] = 'IRAQ';
$app_list_strings['countries_dom']['IRELAND'] = 'IRLANDA';
$app_list_strings['countries_dom']['ISRAEL'] = 'ISRAEL';
$app_list_strings['countries_dom']['ITALY'] = 'ITALIA';
$app_list_strings['countries_dom']['IVORY COAST'] = 'COSTA DE MARFIL';
$app_list_strings['countries_dom']['JAMAICA'] = 'JAMAICA';
$app_list_strings['countries_dom']['JAPAN'] = 'JAPÓN';
$app_list_strings['countries_dom']['JORDAN'] = 'JORDANIA';
$app_list_strings['countries_dom']['KAZAKHSTAN'] = 'KAZAJSTÁN';
$app_list_strings['countries_dom']['KENYA'] = 'KENIA';
$app_list_strings['countries_dom']['KOREA'] = 'COREA';
$app_list_strings['countries_dom']['KOREA, SOUTH'] = 'COREA DEL SUR';
$app_list_strings['countries_dom']['KUWAIT'] = 'KUWAIT';
$app_list_strings['countries_dom']['KYRGYZSTAN'] = 'KIRGUISTÁN';
$app_list_strings['countries_dom']['LAOS'] = 'LAOS';
$app_list_strings['countries_dom']['LATVIA'] = 'LETONIA';
$app_list_strings['countries_dom']['LEBANON'] = 'LÍBANO';
$app_list_strings['countries_dom']['LEEWARD ISLANDS'] = 'ISLAS DE SOTAVENTO';
$app_list_strings['countries_dom']['LESOTHO'] = 'LESOTO';
$app_list_strings['countries_dom']['LIBYA'] = 'LIBIA';
$app_list_strings['countries_dom']['LIECHTENSTEIN'] = 'LIECHTENSTEIN';
$app_list_strings['countries_dom']['LITHUANIA'] = 'LITUANIA';
$app_list_strings['countries_dom']['LUXEMBOURG'] = 'LUXEMBURGO';
$app_list_strings['countries_dom']['MACAO'] = 'MACAO';
$app_list_strings['countries_dom']['MACEDONIA'] = 'MACEDONIA';
$app_list_strings['countries_dom']['MADAGASCAR'] = 'MADAGASCAR';
$app_list_strings['countries_dom']['MALAWI'] = 'MALAWI';
$app_list_strings['countries_dom']['MALAYSIA'] = 'MALASIA';
$app_list_strings['countries_dom']['MALDIVES'] = 'MALDIVAS';
$app_list_strings['countries_dom']['MALI'] = 'MALI';
$app_list_strings['countries_dom']['MALTA'] = 'MALTA';
$app_list_strings['countries_dom']['MARTINIQUE'] = 'MARTINICA';
$app_list_strings['countries_dom']['MAURITANIA'] = 'MAURITANIA';
$app_list_strings['countries_dom']['MAURITIUS'] = 'MAURICIO';
$app_list_strings['countries_dom']['MELANESIA'] = 'MELANESIA';
$app_list_strings['countries_dom']['MEXICO'] = 'MÉXICO';
$app_list_strings['countries_dom']['MOLDOVIA'] = 'MOLDAVIA';
$app_list_strings['countries_dom']['MONACO'] = 'MÓNACO';
$app_list_strings['countries_dom']['MONGOLIA'] = 'MONGOLIA';
$app_list_strings['countries_dom']['MOROCCO'] = 'MARRUECOS';
$app_list_strings['countries_dom']['MOZAMBIQUE'] = 'MOZAMBIQUE';
$app_list_strings['countries_dom']['MYANAMAR'] = 'MYANAMAR';
$app_list_strings['countries_dom']['NAMIBIA'] = 'NAMIBIA';
$app_list_strings['countries_dom']['NEPAL'] = 'NEPAL';
$app_list_strings['countries_dom']['NETHERLANDS'] = 'PAÍSES BAJOS';
$app_list_strings['countries_dom']['NETHERLANDS ANTILLES'] = 'ANTILLAS HOLANDESAS';
$app_list_strings['countries_dom']['NETHERLANDS ANTILLES NEUTRAL ZONE'] = 'ANTILLAS HOLANDESAS ZONA NEUTRAL';
$app_list_strings['countries_dom']['NEW CALADONIA'] = 'NUEVA CALEDONIA';
$app_list_strings['countries_dom']['NEW HEBRIDES'] = 'NUEVAS HÉBRIDAS';
$app_list_strings['countries_dom']['NEW ZEALAND'] = 'NUEVA ZELANDA';
$app_list_strings['countries_dom']['NICARAGUA'] = 'NICARAGUA';
$app_list_strings['countries_dom']['NIGER'] = 'NÍGER';
$app_list_strings['countries_dom']['NIGERIA'] = 'NIGERIA';
$app_list_strings['countries_dom']['NORFOLK ISLAND'] = 'ISLA NORFOLK';
$app_list_strings['countries_dom']['NORWAY'] = 'NORUEGA';
$app_list_strings['countries_dom']['OMAN'] = 'OMÁN';
$app_list_strings['countries_dom']['OTHER'] = 'OTRO';
$app_list_strings['countries_dom']['PACIFIC ISLAND'] = 'ISLA DEL PACIFICO';
$app_list_strings['countries_dom']['PAKISTAN'] = 'PAKISTÁN';
$app_list_strings['countries_dom']['PANAMA'] = 'PANAMÁ';
$app_list_strings['countries_dom']['PAPUA NEW GUINEA'] = 'PAPÚA NUEVA GUINEA';
$app_list_strings['countries_dom']['PARAGUAY'] = 'PARAGUAY';
$app_list_strings['countries_dom']['PERU'] = 'PERÚ';
$app_list_strings['countries_dom']['PHILIPPINES'] = 'FILIPINAS';
$app_list_strings['countries_dom']['POLAND'] = 'POLONIA';
$app_list_strings['countries_dom']['PORTUGAL'] = 'PORTUGAL';
$app_list_strings['countries_dom']['PORTUGUESE TIMOR'] = 'TIMOR ORIENTAL';
$app_list_strings['countries_dom']['PUERTO RICO'] = 'PUERTO RICO';
$app_list_strings['countries_dom']['QATAR'] = 'QATAR';
$app_list_strings['countries_dom']['REPUBLIC OF BELARUS'] = 'REPÚBLICA DE BIELORRUSIA';
$app_list_strings['countries_dom']['REPUBLIC OF SOUTH AFRICA'] = 'REPÚBLICA DE SUDÁFRICA';
$app_list_strings['countries_dom']['REUNION'] = 'REUNIÓN';
$app_list_strings['countries_dom']['ROMANIA'] = 'RUMANÍA';
$app_list_strings['countries_dom']['RUSSIA'] = 'RUSIA';
$app_list_strings['countries_dom']['RWANDA'] = 'RUANDA';
$app_list_strings['countries_dom']['RYUKYU ISLANDS'] = 'ISLAS DE RYUKYU';
$app_list_strings['countries_dom']['SABAH'] = 'SABAH';
$app_list_strings['countries_dom']['SAN MARINO'] = 'SAN MARINO';
$app_list_strings['countries_dom']['SAUDI ARABIA'] = 'ARABIA SAUDITA';
$app_list_strings['countries_dom']['SENEGAL'] = 'SENEGAL';
$app_list_strings['countries_dom']['SERBIA'] = 'SERBIA';
$app_list_strings['countries_dom']['SEYCHELLES'] = 'SEYCHELLES';
$app_list_strings['countries_dom']['SIERRA LEONE'] = 'SIERRA LEONE';
$app_list_strings['countries_dom']['SINGAPORE'] = 'SINGAPUR';
$app_list_strings['countries_dom']['SLOVAKIA'] = 'ESLOVAQUIA';
$app_list_strings['countries_dom']['SLOVENIA'] = 'ESLOVENIA';
$app_list_strings['countries_dom']['SOMALILIAND'] = 'SOMALILIAND';
$app_list_strings['countries_dom']['SOUTH AFRICA'] = 'SUDÁFRICA';
$app_list_strings['countries_dom']['SOUTH YEMEN'] = 'YEMEN DEL SUR';
$app_list_strings['countries_dom']['SPAIN'] = 'ESPAÑA';
$app_list_strings['countries_dom']['SPANISH SAHARA'] = 'SAHARA ESPAÑOL';
$app_list_strings['countries_dom']['SRI LANKA'] = 'SRI LANKA';
$app_list_strings['countries_dom']['ST. KITTS AND NEVIS'] = 'ST. KITTS AND NEVIS';
$app_list_strings['countries_dom']['ST. LUCIA'] = 'SANTA LUCÍA';
$app_list_strings['countries_dom']['SUDAN'] = 'SUDÁN';
$app_list_strings['countries_dom']['SURINAM'] = 'SURINAM';
$app_list_strings['countries_dom']['SW AFRICA'] = 'SO DE ÁFRICA';
$app_list_strings['countries_dom']['SWAZILAND'] = 'SWAZILANDIA';
$app_list_strings['countries_dom']['SWEDEN'] = 'SUECIA';
$app_list_strings['countries_dom']['SWITZERLAND'] = 'SUIZA';
$app_list_strings['countries_dom']['SYRIA'] = 'SIRIA';
$app_list_strings['countries_dom']['TAIWAN'] = 'TAIWÁN';
$app_list_strings['countries_dom']['TAJIKISTAN'] = 'TAYIKISTÁN';
$app_list_strings['countries_dom']['TANZANIA'] = 'TANZANIA';
$app_list_strings['countries_dom']['THAILAND'] = 'TAILANDIA';
$app_list_strings['countries_dom']['TONGA'] = 'TONGA';
$app_list_strings['countries_dom']['TRINIDAD'] = 'TRINIDAD';
$app_list_strings['countries_dom']['TUNISIA'] = 'TÚNEZ';
$app_list_strings['countries_dom']['TURKEY'] = 'TURQUÍA';
$app_list_strings['countries_dom']['UGANDA'] = 'UGANDA';
$app_list_strings['countries_dom']['UKRAINE'] = 'UCRANIA';
$app_list_strings['countries_dom']['UNITED ARAB EMIRATES'] = 'EMIRATOS ÁRABES UNIDOS';
$app_list_strings['countries_dom']['UNITED KINGDOM'] = 'REINO UNIDO';
$app_list_strings['countries_dom']['UPPER VOLTA'] = 'ALTO VOLTA';
$app_list_strings['countries_dom']['URUGUAY'] = 'URUGUAY';
$app_list_strings['countries_dom']['US PACIFIC ISLAND'] = 'ISLAS DEL PACÍFICO ESTADOS UNIDOS';
$app_list_strings['countries_dom']['US VIRGIN ISLANDS'] = 'ISLAS VÍRGENES DE EE.UU.';
$app_list_strings['countries_dom']['USA'] = 'EE.UU.';
$app_list_strings['countries_dom']['UZBEKISTAN'] = 'UZBEKISTÁN';
$app_list_strings['countries_dom']['VANUATU'] = 'VANUATU';
$app_list_strings['countries_dom']['VATICAN CITY'] = 'CIUDAD DEL VATICANO';
$app_list_strings['countries_dom']['VENEZUELA'] = 'VENEZUELA';
$app_list_strings['countries_dom']['VIETNAM'] = 'VIETNAM';
$app_list_strings['countries_dom']['WAKE ISLAND'] = 'ISLA WAKE';
$app_list_strings['countries_dom']['WEST INDIES'] = 'ANTILLAS';
$app_list_strings['countries_dom']['WESTERN SAHARA'] = 'SAHARA OCCIDENTAL';
$app_list_strings['countries_dom']['YEMEN'] = 'YEMEN';
$app_list_strings['countries_dom']['ZAIRE'] = 'ZAIRE';
$app_list_strings['countries_dom']['ZAMBIA'] = 'ZAMBIA';
$app_list_strings['countries_dom']['ZIMBABWE'] = 'ZIMBABWE';
$app_list_strings['countries_dom'][''] = '';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_salutation_list.php

 // created: 2016-08-30 22:50:38

$app_list_strings['salutation_list']=array (
  '' => '',
  'Sr.' => 'Sr.',
  'Sra.' => 'Sra.',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_unidad_neg_c_list.php

 // created: 2016-09-05 15:10:27

$app_list_strings['sasa_unidad_neg_c_list']=array (
  0 => 'Venta Directa',
  1 => 'Venta al paso',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_moduleList.php

 //created: 2016-06-30 00:25:54

$app_list_strings['moduleList']['RevenueLineItems']='Líneas de Ingreso';
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_record_type_display_notes.php

 // created: 2016-06-30 00:25:54

$app_list_strings['record_type_display_notes']=array (
  'Accounts' => 'Cuenta',
  'Contacts' => 'Contacto',
  'Opportunities' => 'Oportunidad',
  'Tasks' => 'Tarea',
  'ProductTemplates' => 'Catálogo de Productos',
  'Quotes' => 'Presupuesto',
  'Products' => 'Línea de la Oferta',
  'Contracts' => 'Contrato',
  'Emails' => 'Correo electrónico',
  'Bugs' => 'Incidencia',
  'Project' => 'Proyecto',
  'ProjectTask' => 'Tarea de Proyecto',
  'Prospects' => 'Público Objetivo',
  'Cases' => 'Caso',
  'Leads' => 'Cliente Potencial',
  'Meetings' => 'Reunión',
  'Calls' => 'Llamada',
  'KBContents' => 'Base de Conocimiento',
  'RevenueLineItems' => 'Líneas de Ingreso',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_cargo_c_list.php

 // created: 2016-09-13 14:55:19

$app_list_strings['sasa_cargo_c_list']=array (
  0 => 'Vendedor',
  1 => 'Lider',
  2 => 'Gerente',
  3 => 'Técnico',
  4 => 'Transportador',
  5 => 'Rutero',
  6 => 'Impulsador',
  7 => 'Ejecutivo',
  8 => 'Personal Call Center',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_tipodellamada_list.php

 // created: 2016-09-04 13:13:05

$app_list_strings['sasa_tipodellamada_list']=array (
  '' => '',
  0 => 'Llamada de seguimiento al caso',
  1 => 'Primera llamada',
  2 => 'Segunda llamada',
  3 => 'Tercer llamada',
  4 => 'Llamada de apertura de caso',
  5 => 'Llamada de cierre de caso',
  6 => 'Llamada Encuesta de satisfacción',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_proceso_c_list.php

 // created: 2016-10-08 01:26:35

$app_list_strings['sasa_proceso_c_list']=array (
  '' => '',
  0 => 'Cartera',
  1 => 'Comercial',
  2 => 'Compañía',
  3 => 'Cuentas por Pagar',
  4 => 'Impuestos',
  5 => 'Informática',
  6 => 'Línea Ética',
  7 => 'Logística',
  8 => 'Mantenimiento',
  9 => 'Mercadeo/Trade',
  10 => 'Producto',
  11 => 'Servicio',
  12 => 'Soporte Portal de Proveedores',
  13 => 'Tesoreria',
  14 => 'Proveedores',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_parent_type_display.php

 // created: 2016-06-30 00:25:54

$app_list_strings['parent_type_display']=array (
  'Accounts' => 'Cuenta',
  'Contacts' => 'Contacto',
  'Tasks' => 'Tarea',
  'Opportunities' => 'Oportunidad',
  'Products' => 'Línea de la Oferta',
  'Quotes' => 'Presupuesto',
  'Bugs' => 'Incidencias',
  'Cases' => 'Caso',
  'Leads' => 'Cliente Potencial',
  'Project' => 'Proyecto',
  'ProjectTask' => 'Tarea de Proyecto',
  'Prospects' => 'Público Objetivo',
  'KBContents' => 'Base de Conocimiento',
  'RevenueLineItems' => 'Líneas de Ingreso',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.materiales.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutm_materiales'] = 'Materiales';
$app_list_strings['moduleListSingular']['nutm_materiales'] = 'Material';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_ctrl_sec_c_list.php

 // created: 2016-09-29 23:12:23

$app_list_strings['sasa_ctrl_sec_c_list']=array (
  1 => '1',
  2 => '2',
  3 => '3',
  4 => '4',
  5 => '5',
  6 => '6',
  7 => '7',
  8 => '8',
  9 => '9',
  10 => '10',
  11 => '11',
  12 => '12',
  13 => '13',
  14 => '14',
  15 => '15',
  16 => '16',
  17 => '17',
  18 => '18',
  19 => '19',
  20 => '20',
  21 => '21',
  22 => '22',
  23 => '23',
  24 => '24',
  25 => '25',
  26 => '26',
  27 => '27',
  28 => '28',
  29 => '29',
  30 => '30',
  31 => '31',
  32 => '32',
  33 => '33',
  34 => '34',
  35 => '35',
  36 => '36',
  37 => '37',
  38 => '38',
  39 => '39',
  40 => '40',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.PersonalizacionesCasosTipificaciones.php

$app_list_strings['sasa_pregunta1_list'] = array (
  '' => '',
  1 => '1',
  2 => '2',
  3 => '3',
  4 => '4',
  5 => '5',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_tipodefalla_c_list'] = array (
  '' => '',
  'Apelmazamiento' => 'Apelmazamiento',
  'Falla billetero' => 'Falla billetero',
  'Falla monedero' => 'Falla monedero',
  'Desconfigurada' => 'Desconfigurada',
  'No dispensa bebidas' => 'No dispensa bebidas',
  'Problemas de temperatura' => 'Problemas de temperatura',
  'Problemas electricos' => 'Problemas electricos',
  'No entrega producto' => 'No entrega producto',
  'Falla bluevending' => 'Falla bluevending',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_regional_list'] = array (
  '' => '',
  'Medellin' => 'Medellín',
  'Bogota' => 'Bogotá',
  'Cali' => 'Cali',
  'Barranquilla' => 'Barranquilla',
  'Bucaramanga' => 'Bucaramanga',
  'Ibague' => 'Ibagué',
  'Pereira' => 'Pereira',
  'No_Aplica' => 'No Aplica',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_subcategoria_c_list'] = array (
  '' => '',
  0 => 'Académica',
  1 => 'Actitud',
  2 => 'Activos',
  3 => 'Actualización de Datos',
  4 => 'Actualización de Datos/Datos Básicos',
  5 => 'Álbum/Láminas/Palitos',
  6 => 'Almacenamiento/Manejo',
  7 => 'Anomalía Apropiación de Recursos',
  8 => 'Anomalía Conflicto de Intereses',
  9 => 'Anomalía Derechos Humanos',
  10 => 'Anomalía Otros ',
  11 => 'Anomalía Prácticas de Comercializadores',
  12 => 'Anomalía Prácticas de Proveedores',
  13 => 'Anomalía Prácticas Laborales',
  14 => 'Anomalía Temas Personales ',
  15 => 'Apariencia',
  16 => 'Apertura o Ampliación de Crédito',
  17 => 'Asesoría',
  18 => 'Ausencia de Producto en Punto de Venta',
  19 => 'Autoevaluación Pacto Global',
  20 => 'Beneficios/Características',
  21 => 'Bloqueo de pago',
  22 => 'Bloqueo de Pago Tipo "D"',
  23 => 'Broma',
  24 => 'Cambio de Frecuencia',
  25 => 'Cambio Día',
  26 => 'Campaña/Promoción',
  27 => 'Características Sensoriales',
  28 => 'Cartera',
  29 => 'Caso de Prueba',
  30 => 'Centro de Empaque',
  31 => 'Certificado de Ventas',
  32 => 'Certificados',
  33 => 'Certificados Declaración de Renta',
  34 => 'Cliente Inactivo',
  35 => 'Cliente Inactivo/Bloqueado',
  36 => 'Cliente Nuevo',
  37 => 'Código de Conducta',
  38 => 'Competencia',
  39 => 'Completar Información de Caso Anterior',
  40 => 'Comunicación',
  41 => 'Condiciones de Pago',
  42 => 'Confirmación de Reporte',
  43 => 'Confirmación Recepción Pedido Electrónico',
  44 => 'Consulta de Artículos',
  45 => 'Consulta Facturas',
  46 => 'Contacto Repetido',
  47 => 'Contacto Web',
  48 => 'Contaminación Microbiológica',
  49 => 'Contenido/Presentaciones/Embalajes',
  50 => 'Cotizaciones',
  51 => 'Cursos/Programas Especiales',
  52 => 'Daño a Terceros',
  53 => 'Datos básicos de cliente código ERP/dígito de chequeo',
  54 => 'Datos de Vendedor/Gerente/Líder',
  55 => 'Datos Equivocados',
  56 => 'Degustación',
  57 => 'Desarrollador Comercial',
  58 => 'Descontinuados',
  59 => 'Desempeño Global',
  60 => 'Despacho de Producto Vencido o Corta Fecha',
  61 => 'Detalle del Pedido',
  62 => 'Devolución de Dinero',
  63 => 'Devolución de Producto',
  64 => 'Días de Reporte o Toma de Pedido',
  65 => 'Direcciones, Teléfonos y Cargos',
  66 => 'Distribución Internacional',
  67 => 'Donaciones',
  68 => 'Elementos de Exhibición y Venta',
  69 => 'Empaque',
  70 => 'Empleo',
  71 => 'Entrega con Corta Fecha',
  72 => 'Entrega Material Pop/Papelería',
  73 => 'Envase',
  74 => 'Envío de Factura Original/Copia',
  75 => 'Equipos Comerciales',
  76 => 'Errores en el Sistema Transaccional',
  77 => 'Espectáculo de Navidad',
  78 => 'Estado de Cuenta',
  79 => 'Estado de la Solicitud',
  80 => 'Estado de Pagos/Consignaciones',
  81 => 'Estado de un Pedido',
  82 => 'Estado del Proceso de Selección',
  83 => 'Estados de Cuenta Proveedores',
  84 => 'Evaluación de Proveedores',
  85 => 'Exención de Impuestos',
  86 => 'Existencias de Producto',
  87 => 'Factura Electrónica',
  88 => 'Factura Registrada Pendiente de Pago Mayores a 10 días',
  89 => 'Facturas Proveedores',
  90 => 'Faltante',
  91 => 'Fecha de Inicio y Fin de Temporada',
  92 => 'Ficha Técnica',
  93 => 'Forma de Preparación/Recetarios',
  94 => 'Fuerza de Ventas',
  95 => 'Horario de Atención',
  96 => 'Inconsistencia en Pagos y Abonos',
  97 => 'Infestación',
  98 => 'Información Especializada',
  99 => 'Información General Cacao',
  100 => 'Información Nutricional/Ingredientes',
  101 => 'Informática',
  102 => 'Inocuidad',
  103 => 'Insatisfacción con el Obsequio',
  104 => 'Insatisfacción con el Producto',
  105 => 'Insatisfacción con el Servicio',
  106 => 'Inventarios en Consignación',
  107 => 'IVR',
  108 => 'Llamada Colgada',
  109 => 'Llamada Equivocada',
  110 => 'Llamada Incompleta',
  111 => 'Llamada Personal Compañía',
  112 => 'Manejo de Equipos Comerciales',
  113 => 'Matrícula de Talonarios',
  114 => 'Mayor o Menor Valor Pagado por Descuento',
  115 => 'Mayor o Menor Valor Pagado por Notas o Impuestos IVA, Rte Fte, ICA',
  116 => 'Medios de Pago/Número Cuentas para Consignar',
  117 => 'Menor de Edad',
  118 => 'Mercaderismo/Impulso',
  119 => 'Modificación del Pedido',
  120 => 'Necesita Llamada de Líder/Vendedor/Mercaderista',
  121 => 'Necesita Visita de Líder/Vendedor/Mercaderista',
  122 => 'No Me Ha Vuelto a Llamar Televendedor',
  123 => 'No me Recogieron la Devolución',
  124 => 'Nota Crédito',
  125 => 'Notificación de Contraseñas',
  126 => 'Ofrecimiento Transporte',
  127 => 'Órdenes de Compra',
  128 => 'Otros',
  129 => 'Pagaré/Paz y Salvo',
  130 => 'Página Web',
  131 => 'Página Web - Contenido',
  132 => 'Pagos que no Registran',
  133 => 'Papelería Ventas por Catálogo',
  134 => 'Patrocinio de Eventos',
  135 => 'Pedido',
  136 => 'Pedido no Esta en el Sistema',
  137 => 'Plan de Fidelización',
  138 => 'Política Comercial',
  139 => 'Politica de Entrega',
  140 => 'Politicas de Equipos Comerciales',
  141 => 'Portafolio General',
  142 => 'Práctica Empresarial',
  143 => 'Precios, Descuentos y Alzas',
  144 => 'Premio',
  145 => 'Preparación',
  146 => 'Primer Nivel',
  147 => 'Problemas de Peso',
  148 => 'Problemas de Usuario y Contraseña para Ingresar',
  149 => 'Producto Averiado al Momento del Recibo',
  150 => 'Producto Nuevo',
  151 => 'Productos de Temporada',
  152 => 'Programa de Referidos',
  153 => 'Promociones Generales',
  154 => 'Prospecto',
  155 => 'Proveedor Nuevo',
  156 => 'Publicidad Engañosa',
  157 => 'Publicidad/Material POP',
  158 => 'Reclamo en Trámite',
  159 => 'Reclamos y Rechazos',
  160 => 'Recogida de Pago',
  161 => 'Red de Distribución',
  162 => 'Reembolso de Dinero no Elaborado con Reversión',
  163 => 'Referencias Comerciales',
  164 => 'Referencias Comerciales (verbal)',
  165 => 'Relleno de Producto',
  166 => 'Requerimiento Compañías del Grupo',
  167 => 'Requerimiento Mantenimiento',
  168 => 'Requisitos para Ser Proveedor',
  169 => 'Revisión de Ajustes "AB"',
  170 => 'Rutas de Venta/Televenta',
  171 => 'Saldo de Cartera',
  172 => 'Salida Varia',
  173 => 'Sin sistema',
  174 => 'Sistema de Venta Directa',
  175 => 'Sistemas de Gestión Ambiental',
  176 => 'Sobrante',
  177 => 'Soporte Portal ',
  178 => 'Soporte Portal de Clientes',
  179 => 'Stickers Portapapeles',
  180 => 'Tecnica Actualización de Datos',
  181 => 'Tecnica Autoevaluación Pacto Global',
  182 => 'Tecnica Certificados',
  183 => 'Tecnica Código de Conducta',
  184 => 'Tecnica Evaluación de Proveedores',
  185 => 'Tecnica Gestión Ordenes de Mantenimiento',
  186 => 'Tecnica Inventarios en Consignación',
  187 => 'Tecnica Notificación de Contraseñas',
  188 => 'Tecnica Órdenes de Compra',
  189 => 'Tecnica Problemas de Usuario y Contraseña para Ingresar',
  190 => 'Tecnica Reclamos y Rechazos',
  191 => 'Transacción Plan de Entregas',
  192 => 'Transferida a otro Split',
  193 => 'Usuario Cuelga Insatisfecho con el Servicio de la Línea',
  194 => 'Vehículo en Mal Estado',
  195 => 'Vencimiento/Vida Útil',
  196 => 'Vendedor no Autorizó la Devolución',
  197 => 'Vendedor no Hizo la Visita/No Ha Vuelto',
  198 => 'Venta Subproductos/Desechos de Productos/Desechos Industriales',
  199 => 'Ventas a Empleados',
  200 => 'Visita a Mundo Pozuelo',
  201 => 'Visita a Planta',
  202 => 'Workflow Matricula Proveedores',
  203 => 'Estado de Solicitud',
  204 => 'Factura no Registrada en el Sistema',
  205 => 'Comprobante de Pago',
  206 => 'Fecha Límite Factuación',
  207 => 'Ofrecimiento de Insumos y Servicios',
  208 => 'Programación de Pagos',
  209 => 'Descuento por Pronto Pago',
  210 => 'General',
  211 => 'Tecnica Estado de Cuenta',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_fuente_c_list'] = array (
  0 => 'Buzón',
  1 => 'Conmutador',
  2 => 'Contactenos Grupo Nutresa',
  3 => 'Correo Electrónico',
  4 => 'Empleado',
  5 => 'Formulario intranet',
  6 => 'Líneas de servicio',
  7 => 'IVR',
  8 => 'Llamadas de salida',
  9 => 'Página web',
  10 => 'App',
  11 => 'Redes sociales',
  12 => 'Chat',
  '' => '',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sas_consumidorreiterativo_c_list'] = array (
  '' => '',
  'Si' => 'Si',
  'No' => 'No',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_cargo_c_list'] = array (
  '' => '',
  0 => 'Vendedor',
  3 => 'Técnico',
  4 => 'Transportador',
  5 => 'Rutero',
  6 => 'Impulsador',
  7 => 'Ejecutivo',
  8 => 'Personal Call Center',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_activo_falla_c_list'] = array (
  '' => '',
  0 => 'No continua como cliente',
  1 => 'Traslado de local',
  3 => 'Se terminó el contrato',
  4 => 'Problemas de servicio',
  5 => 'Otros',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_activo_motivo_c_list'] = array (
  '' => '',
  0 => 'Máquina Sucia',
  1 => 'No tiene producto',
  2 => 'Devolución incorrecta',
  3 => 'Otros',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_producto_muestra_c_list'] = array (
  '' => '',
  0 => 'Si',
  1 => 'No',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_motivo_list'] = array (
  '' => '',
  0 => 'Contacto No Efectivo',
  1 => 'Felicitación/Agradecimiento',
  2 => 'Información',
  3 => 'Queja',
  4 => 'Solicitud',
  5 => 'Sugerencias',
  6 => 'Estado de la solicitud',
  8 => 'Pendiente por Clasificar',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_relacion_list'] = array (
  '' => '',
  0 => 'Accionista',
  1 => 'Cliente',
  2 => 'Cliente Internacional',
  3 => 'Colaborador',
  4 => 'Consumidor',
  6 => 'Contratista',
  8 => 'Proveedor',
  9 => 'Público general',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['case_status_dom'] = array (
  'New' => 'Nuevo',
  'Assigned' => 'Asignado',
  'Closed' => 'Cerrado',
  'Pending Input' => 'Pendiente de Información',
  'Rejected' => 'Rechazado',
  'Duplicate' => 'Duplicar',
  'Clasificado' => 'Clasificado',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  0 => 'Autorización de Datos',
  1 => 'Colaborador',
  2 => 'Correo Electrónico',
  3 => 'Ferias y Eventos',
  4 => 'Iniciativa Propia',
  5 => 'Medio Digital',
  6 => 'Medios Masivos',
  7 => 'Otros',
  8 => 'Referido',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_proceso_c_list'] = array (
  '' => '',
  0 => 'Cartera',
  1 => 'Comercial',
  2 => 'Compañía',
  3 => 'Cuentas por Pagar',
  4 => 'Impuestos',
  5 => 'Informática',
  6 => 'Línea Ética',
  7 => 'Logística',
  8 => 'Mantenimiento',
  9 => 'Mercadeo/Trade',
  10 => 'Producto',
  11 => 'Servicio',
  12 => 'Soporte Portal de Proveedores',
  13 => 'Tesoreria',
  14 => 'Proveedores',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['dom_switch_bool'] = array (
  '' => '',
  'on' => 'Sí',
  'off' => 'No',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_tipodeservicio_c_list'] = array (
  '' => '',
  'Fumigacion' => 'Fumigacion',
  'Cambio de chapa' => 'Cambio de chapa',
  'Cambio de boquilla' => 'Cambio de boquilla',
  'Reposicion de llave' => 'Reposicion de llave',
  'Accesorio mobileto' => 'Accesorio mobileto',
  'Instalacion medios de pago' => 'Instalacion medios de pago',
  'Modificacion de portafolio' => 'Modificacion de portafolio',
  'Anclajes' => 'Anclajes',
  'Cambio de cilindro' => 'Cambio de cilindro',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_producto_motivos_list'] = array (
  '' => '',
  0 => 'Se acabo el producto',
  1 => 'Se incumplió la visita',
  2 => 'Otros',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_detallle_c_list'] = array (
  '' => '',
  0 => 'Abollado',
  1 => 'Actualización de Datos Consumidor',
  2 => 'Agencia de Cobros',
  3 => 'Alistamiento Mal Realizado',
  4 => 'Amenaza Demanda Actividad Promocional',
  5 => 'Amenaza Demanda Compañía',
  6 => 'Amenaza Demanda Producto',
  151 => 'Anchetas',
  7 => 'Arrugado',
  8 => 'Asesoría para Usar el Portal',
  9 => 'Asignación de Plan Itinerario',
  10 => 'Asistió',
  11 => 'Autoriza Tratamiento de Datos',
  12 => 'Baboso',
  13 => 'Billeteros',
  14 => 'Bloom',
  15 => 'Calidad del Premio',
  16 => 'Call Center y Otros',
  17 => 'Cambio',
  18 => 'Cambio de Dirección',
  19 => 'Cancelación/Modificación',
  20 => 'Cantidad de Vendedores',
  21 => 'Carro Heladero',
  23 => 'Color',
  24 => 'Compactado y Aglomerado',
  26 => 'Condiciones para Ser Cliente',
  25 => 'Condición de Pago',
  27 => 'Congelador Falla Funcional',
  28 => 'Congelador Falla No Funcional',
  29 => 'Contacto No Efectivo',
  30 => 'Contrato de Empresaria',
  31 => 'Cristalizado',
  32 => 'Cuchara o Pitillo',
  22 => 'Código',
  33 => 'Deforme',
  34 => 'Demora en la Entrega',
  35 => 'Derretido',
  36 => 'Digitado No Facturado',
  37 => 'Disminución de Cantidad en Producto',
  38 => 'Easy Open',
  39 => 'Elemento Promocional',
  40 => 'Empaque Sellado Sin Producto',
  41 => 'En Corrugado, Fardo o Bolsa',
  42 => 'En Unidad de Consumo',
  43 => 'En Unidad de Venta',
  44 => 'Entrega',
  45 => 'Entrega de Premios',
  46 => 'Entrega en Dirección Incorrecta',
  47 => 'Entregador',
  48 => 'Entregador no Entregó el Pedido',
  49 => 'Envio de Referencia Equivocada',
  50 => 'Error en la Toma de Pedido',
  51 => 'Error en la Toma de Pedido Televendedor',
  52 => 'Errores de Marcación',
  53 => 'Esquema de Atención',
  54 => 'Exhibición del Punto de Venta',
  55 => 'Experiencias',
  56 => 'Factura Original no Entregada',
  57 => 'Facturado No Despachado',
  58 => 'Falsificación',
  59 => 'Faltante de Producto por Agotado',
  60 => 'Fecha de Vencimiento y Lotes Ilegibles, Errados o Ausentes',
  61 => 'Ficha Técnica',
  62 => 'Foil',
  63 => 'Frecuencia de Visita',
  64 => 'Funcionalidad del Empaque',
  65 => 'Garantía del Premio',
  66 => 'General',
  67 => 'Grasa Lateral',
  68 => 'Inconsistencia en Precio/Pagos o Abonos',
  69 => 'Inflado',
  70 => 'Información Nutricional/Ingredientes',
  71 => 'Información Nutricional/Salud',
  72 => 'Ingreso Página Web',
  73 => 'Inscripción',
  74 => 'Inscrito',
  75 => 'Insuficiente, Ausente o Excesivo',
  76 => 'Interesado',
  77 => 'Inventario No Realizado',
  78 => 'Lechoso',
  80 => 'Llegó Tarde',
  81 => 'Lo Facturado No es lo Entregado',
  79 => 'Líder Ventas por Catálogo',
  82 => 'Mal Estado del Empaque',
  83 => 'Mala Presentación del Producto',
  149 => 'Mama Empresaria',
  84 => 'Manejo de Producto',
  85 => 'Mantenimiento Mal Realizado',
  86 => 'Mantenimiento No Realizado',
  88 => 'Mecánica',
  89 => 'Mecánica de la Campaña/Promoción',
  150 => 'Medios de Pago / Devolución',
  152 => 'Medios de Pago / Transferencia',
  90 => 'Mercaderismo/Impulso',
  91 => 'Montaje de Nuevos Negocios',
  92 => 'Movilización No Realizada',
  87 => 'Máquinas Dispensadoras',
  93 => 'Neveras',
  94 => 'No Atribuible a Compañía',
  95 => 'No Han Recogido',
  96 => 'No Llegó',
  97 => 'No Llegó la Promoción',
  98 => 'No llegó/No Está en el Sistema',
  148 => 'Nuevo Nit',
  99 => 'Objetos Extraño',
  100 => 'Objetos Extraño Metálico',
  146 => 'Ofrece nuevas Máquinas',
  145 => 'Ofrece nuevos productos y publicidad',
  101 => 'Ofrece Nuevos Servicios',
  147 => 'Ofrece procesos logísticos y de Tecnologia',
  102 => 'Olor',
  103 => 'Otros',
  104 => 'Oxidado',
  105 => 'Pedido no Tomado por Políticas Comerciales',
  107 => 'Personal Call Center',
  108 => 'Personal de Activos',
  109 => 'Personal de la Compañía',
  110 => 'Personal Técnico',
  111 => 'Peso Inferior al Declarado',
  112 => 'Premia tu Cliente',
  113 => 'Premio',
  114 => 'Presencia de Moho/Hongos',
  115 => 'Problemas con su Usuario',
  116 => 'Problemas de Visualización/No Carga la Página',
  117 => 'Producto Partido',
  118 => 'Producto Próximo a Vencer',
  119 => 'Producto Vencido',
  120 => 'Publicidad Engañosa',
  106 => 'Pérdida de Vacío',
  121 => 'Quebrado',
  122 => 'Recogida',
  123 => 'Redención de Premios',
  124 => 'Redes Sociales',
  125 => 'Referencias Restringidas',
  126 => 'Registro Sanitario',
  127 => 'Rendimiento',
  144 => 'Retraso o Ausencia de respuesta',
  128 => 'Sabor',
  129 => 'Salud Afectada',
  130 => 'Sellado',
  131 => 'Sellos',
  132 => 'Solicitudes del Cliente',
  133 => 'Textura',
  134 => 'Toma de Pedido Devolución',
  135 => 'Toma de Pedido ERP',
  136 => 'Toma de Pedido Manual',
  137 => 'Usuario y Contraseña Para Ingresar',
  138 => 'Vendedor/Líder/Gerente',
  139 => 'Venta Previa a Temporada',
  140 => 'Ventana de Innovación',
  141 => 'Verde',
  142 => 'Verifica Estatus Premio',
  143 => 'Visualización/Cargue de Página/Navegación',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_motivo_retiro_list'] = array (
  '' => '',
  3 => 'Comercial',
  4 => 'Logística',
  2 => 'Operaciones',
  5 => 'Servicio al cliente',
  1 => 'Tecnico(a)',
  0 => 'Trade',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_elcasoesdeproducto_c_list'] = array (
  '' => '',
  'Si' => 'Si',
  'No' => 'No',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/temp.php
 
$app_list_strings['sasa_operacion_list'] = array (
  '' => '',
  'Directa' => 'Directa',
  'Indirecta' => 'Indirecta',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.campana_por_sociedad.php

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['nutcs_campana_por_sociedad'] = 'Campañas por sociedades';
$app_list_strings['moduleListSingular']['nutcs_campana_por_sociedad'] = 'Campana por sociedad';

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_elcasoesdeproducto_c_list.php

 // created: 2016-09-30 01:15:36

$app_list_strings['sasa_elcasoesdeproducto_c_list']=array (
  '' => '',
  'Si' => 'Si',
  'No' => 'No',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_fuente_c_list.php

 // created: 2016-09-27 01:10:19

$app_list_strings['sasa_fuente_c_list']=array (
  0 => 'Buzón',
  1 => 'Conmutador',
  2 => 'Contactenos Grupo Nutresa',
  3 => 'Correo Electrónico',
  4 => 'Empleado',
  5 => 'Formulario intranet',
  6 => 'Líneas de servicio',
  7 => 'IVR',
  8 => 'Llamadas de salida',
  9 => 'Página web',
  10 => 'App',
  11 => 'Redes sociales',
  12 => 'Chat',
  '' => '',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_compania_c_list.php

 // created: 2016-09-27 00:51:22

$app_list_strings['sasa_compania_c_list']=array (
  '' => '',
  1 => 'Alimentos cárnicos s.a.s. (aann)',
  2 => 'Alimentos Cárnicos Zona Franca Santa Fe',
  3 => 'CNCH Costa Rica',
  4 => 'Colcafé',
  5 => 'Comarrico',
  6 => 'Comercial nutresa s.a.s. (agco)',
  7 => 'Compañía de galletas noel s.a.s. (afgn)',
  8 => 'Compañía nacional de chocolates s.a.s. (abcn)',
  9 => 'Doria',
  10 => 'Fundacion grupo nutresa (ljfi)',
  11 => 'Gestión cargo zona franca s.a.s. (sagz)',
  12 => 'Grupo nutresa s.a. (fhia)',
  13 => 'Industria colombiana de café s.a.s. (aecm)',
  14 => 'Industria de alimentos zenú s.a.s. (aaiz)',
  15 => 'Industrias aliadas s.a.s (aeal)',
  16 => 'La recetta soluciones gastronómic inte (aglr)',
  17 => 'Litoempaques s.a.s (mflt)',
  18 => 'Meals',
  19 => 'Mercadeo de alimen colom s.a.s. meals (adml)',
  20 => 'Molinos santa marta s.a.s. (afms)',
  21 => 'Nacional de Chocolates',
  22 => 'Noel',
  23 => 'Novaventa s.a.s. (agno)',
  24 => 'Opperar Colombia (sioc)',
  25 => 'Pastas comarrico s.a.s. (acpa)',
  26 => 'Pozuelo',
  27 => 'Productos alimenticios doria s.a.s. (acdr)',
  28 => 'Servicios nutresa s.a.s. (siss)',
  29 => 'Setas de Colombia',
  30 => 'Tropical coffe company s.a.s. (aebs)',
  31 => 'Vidarium (lkvd)',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_pregunta1_list.php

 // created: 2017-01-14 20:21:54

$app_list_strings['sasa_pregunta1_list']=array (
  '' => '',
  1 => '1',
  2 => '2',
  3 => '3',
  4 => '4',
  5 => '5',
  10 => 'N/A',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_dom_switch_bool.php

 // created: 2017-01-14 20:23:26

$app_list_strings['dom_switch_bool']=array (
  '' => '',
  'on' => 'Sí',
  'off' => 'No',
  10 => 'N/A',
);
?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_lista_respuesta_list.php

 // created: 2017-01-14 22:01:22

$app_list_strings['sasa_lista_respuesta_list']=array (
  '' => '',
  0 => 'Si',
  1 => 'No',
  2 => 'Sin respuesta',
);

?>
<?php
// Merged from custom/Extension/application/Ext/Language/es_ES.sugar_sasa_lista_respuesta_c_list.php

 // created: 2017-01-14 21:38:34

$app_list_strings['sasa_lista_respuesta_c_list']=array (
  '' => '',
  0 => 'Si',
  1 => 'No',
  2 => 'Sin respuesta',
);

?>
<?php
 // created: 2017-01-26 16:45:15

$app_list_strings['sasa_subcategoria_c_list']=array (
  '' => '',
  0 => 'Académica',
  1 => 'Actitud',
  2 => 'Activos',
  3 => 'Actualización de Datos',
  4 => 'Actualización de Datos/Datos Básicos',
  5 => 'Álbum/Láminas/Palitos',
  6 => 'Almacenamiento/Manejo',
  7 => 'Anomalía Apropiación de Recursos',
  8 => 'Anomalía Conflicto de Intereses',
  9 => 'Anomalía Derechos Humanos',
  10 => 'Anomalía Otros ',
  11 => 'Anomalía Prácticas de Comercializadores',
  12 => 'Anomalía Prácticas de Proveedores',
  13 => 'Anomalía Prácticas Laborales',
  14 => 'Anomalía Temas Personales ',
  15 => 'Apariencia',
  16 => 'Apertura o Ampliación de Crédito',
  17 => 'Asesoría',
  18 => 'Ausencia de Producto en Punto de Venta',
  19 => 'Autoevaluación Pacto Global',
  20 => 'Beneficios/Características',
  21 => 'Bloqueo de pago',
  22 => 'Bloqueo de Pago Tipo "D"',
  23 => 'Broma',
  24 => 'Cambio de Frecuencia',
  25 => 'Cambio Día',
  26 => 'Campaña/Promoción',
  27 => 'Características Sensoriales',
  28 => 'Cartera',
  29 => 'Caso de Prueba',
  30 => 'Centro de Empaque',
  31 => 'Certificado de Ventas',
  32 => 'Certificados',
  33 => 'Certificados Declaración de Renta',
  34 => 'Cliente Inactivo',
  35 => 'Cliente Inactivo/Bloqueado',
  36 => 'Cliente Nuevo',
  37 => 'Código de Conducta',
  38 => 'Competencia',
  39 => 'Completar Información de Caso Anterior',
  40 => 'Comunicación',
  41 => 'Condiciones de Pago',
  42 => 'Confirmación de Reporte',
  43 => 'Confirmación Recepción Pedido Electrónico',
  44 => 'Consulta de Artículos',
  45 => 'Consulta Facturas',
  46 => 'Contacto Repetido',
  47 => 'Contacto Web',
  48 => 'Contaminación Microbiológica',
  49 => 'Contenido/Presentaciones/Embalajes',
  50 => 'Cotizaciones',
  51 => 'Cursos/Programas Especiales',
  52 => 'Daño a Terceros',
  53 => 'Datos básicos de cliente código ERP/dígito de chequeo',
  54 => 'Datos de Vendedor/Gerente/Líder',
  55 => 'Datos Equivocados',
  56 => 'Degustación',
  57 => 'Desarrollador Comercial',
  58 => 'Descontinuados',
  59 => 'Desempeño Global',
  60 => 'Despacho de Producto Vencido o Corta Fecha',
  61 => 'Detalle del Pedido',
  62 => 'Devolución de Dinero',
  63 => 'Devolución de Producto',
  64 => 'Días de Reporte o Toma de Pedido',
  65 => 'Direcciones, Teléfonos y Cargos',
  66 => 'Distribución Internacional',
  67 => 'Donaciones',
  68 => 'Elementos de Exhibición y Venta',
  69 => 'Empaque',
  70 => 'Empleo',
  71 => 'Entrega con Corta Fecha',
  72 => 'Entrega Material Pop/Papelería',
  73 => 'Envase',
  74 => 'Envío de Factura Original/Copia',
  75 => 'Equipos Comerciales',
  76 => 'Errores en el Sistema Transaccional',
  77 => 'Espectáculo de Navidad',
  78 => 'Estado de Cuenta',
  79 => 'Estado de la Solicitud',
  80 => 'Estado de Pagos/Consignaciones',
  81 => 'Estado de un Pedido',
  82 => 'Estado del Proceso de Selección',
  83 => 'Estados de Cuenta Proveedores',
  84 => 'Evaluación de Proveedores',
  85 => 'Exención de Impuestos',
  86 => 'Existencias de Producto',
  87 => 'Factura Electrónica',
  88 => 'Factura Registrada Pendiente de Pago Mayores a 10 días',
  89 => 'Facturas Proveedores',
  90 => 'Faltante',
  91 => 'Fecha de Inicio y Fin de Temporada',
  92 => 'Ficha Técnica',
  93 => 'Forma de Preparación/Recetarios',
  94 => 'Fuerza de Ventas',
  95 => 'Horario de Atención',
  96 => 'Inconsistencia en Pagos y Abonos',
  97 => 'Infestación',
  98 => 'Información Especializada',
  99 => 'Información General Cacao',
  100 => 'Información Nutricional/Ingredientes',
  101 => 'Informática',
  102 => 'Inocuidad',
  103 => 'Insatisfacción con el Obsequio',
  104 => 'Insatisfacción con el Producto',
  105 => 'Insatisfacción con el Servicio',
  106 => 'Inventarios en Consignación',
  107 => 'IVR',
  108 => 'Llamada Colgada',
  109 => 'Llamada Equivocada',
  110 => 'Llamada Incompleta',
  111 => 'Llamada Personal Compañía',
  112 => 'Manejo de Equipos Comerciales',
  113 => 'Matrícula de Talonarios',
  114 => 'Mayor o Menor Valor Pagado por Descuento',
  115 => 'Mayor o Menor Valor Pagado por Notas o Impuestos IVA, Rte Fte, ICA',
  116 => 'Medios de Pago/Número Cuentas para Consignar',
  117 => 'Menor de Edad',
  118 => 'Mercaderismo/Impulso',
  119 => 'Modificación del Pedido',
  120 => 'Necesita Llamada de Líder/Vendedor/Mercaderista',
  121 => 'Necesita Visita de Líder/Vendedor/Mercaderista',
  122 => 'No Me Ha Vuelto a Llamar Televendedor',
  123 => 'No me Recogieron la Devolución',
  124 => 'Nota Crédito',
  125 => 'Notificación de Contraseñas',
  126 => 'Ofrecimiento Transporte',
  127 => 'Órdenes de Compra',
  128 => 'Otros',
  129 => 'Pagaré/Paz y Salvo',
  130 => 'Página Web',
  131 => 'Página Web - Contenido',
  132 => 'Pagos que no Registran',
  133 => 'Papelería Ventas por Catálogo',
  134 => 'Patrocinio de Eventos',
  135 => 'Pedido',
  136 => 'Pedido no Esta en el Sistema',
  137 => 'Plan de Fidelización',
  138 => 'Política Comercial',
  139 => 'Política de Entrega',
  140 => 'Politicas de Equipos Comerciales',
  141 => 'Portafolio General',
  142 => 'Práctica Empresarial',
  143 => 'Precios, Descuentos y Alzas',
  144 => 'Premio',
  145 => 'Preparación',
  146 => 'Primer Nivel',
  147 => 'Problemas de Peso',
  148 => 'Problemas de Usuario y Contraseña para Ingresar',
  149 => 'Producto Averiado al Momento del Recibo',
  150 => 'Producto Nuevo',
  151 => 'Productos de Temporada',
  152 => 'Programa de Referidos',
  153 => 'Promociones Generales',
  154 => 'Prospecto',
  155 => 'Proveedor Nuevo',
  156 => 'Publicidad Engañosa',
  157 => 'Publicidad/Material POP',
  158 => 'Reclamo en Trámite',
  159 => 'Reclamos y Rechazos',
  160 => 'Recogida de Pago',
  161 => 'Red de Distribución',
  162 => 'Reembolso de Dinero no Elaborado con Reversión',
  163 => 'Referencias Comerciales',
  164 => 'Referencias Comerciales (verbal)',
  165 => 'Relleno de Producto',
  166 => 'Requerimiento Compañías del Grupo',
  167 => 'Requerimiento Mantenimiento',
  168 => 'Requisitos para Ser Proveedor',
  169 => 'Revisión de Ajustes "AB"',
  170 => 'Rutas de Venta/Televenta',
  171 => 'Saldo de Cartera',
  172 => 'Salida Varia',
  173 => 'Sin sistema',
  174 => 'Sistema de Venta Directa',
  175 => 'Sistemas de Gestión Ambiental',
  176 => 'Sobrante',
  177 => 'Soporte Portal ',
  178 => 'Soporte Portal de Clientes',
  179 => 'Stickers Portapapeles',
  180 => 'Tecnica Actualización de Datos',
  181 => 'Tecnica Autoevaluación Pacto Global',
  182 => 'Tecnica Certificados',
  183 => 'Tecnica Código de Conducta',
  184 => 'Tecnica Evaluación de Proveedores',
  185 => 'Tecnica Gestión Ordenes de Mantenimiento',
  186 => 'Tecnica Inventarios en Consignación',
  187 => 'Tecnica Notificación de Contraseñas',
  188 => 'Tecnica Órdenes de Compra',
  189 => 'Tecnica Problemas de Usuario y Contraseña para Ingresar',
  190 => 'Tecnica Reclamos y Rechazos',
  191 => 'Transacción Plan de Entregas',
  192 => 'Transferida a otro Split',
  193 => 'Usuario Cuelga Insatisfecho con el Servicio de la Línea',
  194 => 'Vehículo en Mal Estado',
  195 => 'Vencimiento/Vida Útil',
  196 => 'Vendedor no Autorizó la Devolución',
  197 => 'Vendedor no Hizo la Visita/No Ha Vuelto',
  198 => 'Venta Subproductos/Desechos de Productos/Desechos Industriales',
  199 => 'Ventas a Empleados',
  200 => 'Visita a Mundo Pozuelo',
  201 => 'Visita a Planta',
  202 => 'Workflow Matricula Proveedores',
  203 => 'Estado de Solicitud',
  204 => 'Factura no Registrada en el Sistema',
  205 => 'Comprobante de Pago',
  206 => 'Fecha Límite Factuación',
  207 => 'Ofrecimiento de Insumos y Servicios',
  208 => 'Programación de Pagos',
  209 => 'Descuento por Pronto Pago',
  210 => 'General',
  211 => 'Tecnica Estado de Cuenta',
  212 => 'No Tiene Usuario de Ingreso',
  213 => 'Agencias de Cobro',
  214 => 'Cupo total de credito',
  215 => 'Flexibilizacion',
  216 => 'Valor de la nota credito',
  217 => 'Club de privilegios',
  218 => 'Confirmacion Evento',
  219 => 'Cuando me llega el pedido',
  220 => 'Fecha Toma de pedido telefonico o Buzon',
  221 => 'Toma de pedido por la Web',
  222 => 'Fecha limite de pago',
  223 => 'Lugar y fecha de encuentro',
  224 => 'Plan de premios',
  225 => 'Politicas de concursos',
  226 => 'Estrategias de la campaña',
  227 => 'Agotados en factura',
  228 => 'Pedido anulado',
  229 => 'Pedido recortado',
  230 => 'Planeacion de la demanda',
  231 => 'Estrategias del catalogo',
  232 => 'Productos del catalogo',
  233 => 'Activacion por Web',
  234 => 'Caso con respuesta',
  235 => 'Devoluciones por Web',
  236 => 'Pedido ficticio Web',
  237 => 'Pagos Web',
  238 => 'APP',
  239 => 'Pedidos Web',
  240 => 'Ordenes de pedido',
  241 => 'Medio preferente de contacto',
  242 => 'Devoluciones',
  243 => 'No registra en Agencia',
  244 => 'Balance Collection',
  245 => 'Pagaré',
  246 => 'Paz y salvo',
  247 => 'Cliente nuevo Sin referir',
  248 => 'Cliente nuevo  Reinscripcion',
  249 => 'Creacion cliente nuevo 903',
  250 => 'Envio de catalogos',
  251 => 'Toma de Pedido',
  252 => 'Reestablecer Contraseña Web',
  253 => 'Nueva líder',
  254 => 'Reversión nota crédito',
  255 => 'Proyecto Planeación de la Demanda',
  256 => 'Suprimir Datos',
  257 => 'Retracto de Premio No Inventariable',
  258 => 'Saldo en contra',
  259 => 'Saldo por pedido que no recibio',
  260 => 'Posible Crisis',
  261 => 'Cliente Nuevo no contactado',
  262 => 'Inscripciones X otro en blanco lider',
  263 => 'Reconocimiento de puntos',
  264 => 'Cajas en mal estado',
  265 => 'Incumplimiento a entrega fuerza mayor',
  266 => 'Pedido Desmantelado',
  267 => 'Faltante de producto por agotado',
  268 => 'Pago a Mamá Lider',
  269 => 'Bien referido',
  270 => 'Premio de estrategia no recibido',
  271 => 'Garantia de premios No inventariables',
  272 => 'Entrega premios fuera de pedido',
  273 => 'Actitud Transportador',
  274 => 'Caja cruzada',
  275 => 'Devolución no efectiva',
  276 => 'Devolución Pedido Completo',
  277 => 'Faltante de Factura original',
  278 => 'Faltante Catalogo',
  279 => 'Faltante en elemento promocional',
  280 => 'Faltante Paquete de Inscripcion',
  281 => 'Lo Facturado no es lo entregado',
  282 => 'Nota crédito no elaborada',
  283 => 'Pedido Completo Cruzado en nombre',
  284 => 'Pedido Completo Cruzado en contenido',
  285 => 'Pedido Entregado en direccion incorrecta',
  286 => 'Pedido entregado fuera de promesa',
  287 => 'Pedido llego Partido',
  288 => 'Diferencia en precios',
  289 => 'Sustitutos',
  290 => 'Demandas y Derechos de Petición',
  291 => 'Apariencia  Bloom',
  292 => 'Apariencia Derretido',
  293 => 'Ausencia de respuesta o solución',
  294 => 'Pedido Facturado no despachado',
  295 => 'Contraseña no recibida Web',
  296 => 'Inconsistencias con pedidos o devoluciones Web',
  297 => 'Inconsistencias Web',
  298 => 'Página web caida o no disponible',
  299 => 'Inconsistencias con Pagos Web',
  300 => 'Almacenamiento/Manejo/Transporte',
  303 => 'Ampliacion Plazo de Pago',
  304 => 'Anchetas',
  305 => 'Apertura o Ampliación del Crédito Negada',
  306 => 'Aplazamiento fecha cheque postfechado',
  307 => 'Atención de Contacto/Requerimiento',
  308 => 'Baja rotación en punto de venta',
  309 => 'Cambio de rutero',
  310 => 'Cambio temporal de rutero',
  311 => 'Cheque Devueltos',
  312 => 'Cizalla',
  313 => 'Composicion de producto/relleno excesivo, insuficiente o ausente',
  314 => 'Condiciones comerciales diferentes a otros clientes',
  315 => 'Confirmacion recepcion pedido electronico',
  316 => 'Consignación de cheque antes de tiempo',
  317 => 'Contacto Web Repetido',
  318 => 'El Vendedor no Autorizó Recoger la Devolución',
  319 => 'Envio de Album/Catalogo/Recetario',
  320 => 'Exportación de café',
  321 => 'Inconsistencias en descuentos y promociones',
  322 => 'Informacion Especializada',
  323 => 'Muestras',
  324 => 'No realizaron activación de código',
  325 => 'Pago no recogido',
  326 => 'Pago recogido en fecha/hora no acordada',
  327 => 'Pedido Manual',
  328 => 'Preparacion',
  329 => 'Producto de la competencia',
  330 => 'Recibos de Pago',
  331 => 'Requerimientos compañias del grupo',
  332 => 'Retirar cliente no objetivo',
  333 => 'Retirar cliente por cierre o traslado',
  334 => 'Transporte/Embajador/Ayudante de Ventas',
  335 => 'Reporte en centrales de información',
  336 => 'Premio No llego Referido por otro o en Blanco',
  337 => 'Llegó partido Cárnicos y Alpina Cali',
  338 => 'Material de Encuentro',
  339 => 'Carácteristicas diferentes a las del catalogo',
);
?>
<?php
 // created: 2016-09-24 23:52:16

$app_list_strings['sasa_detallle_c_list'] = array (
  '' => '',
  0 => 'Abollado',
  1 => 'Actualización de Datos Consumidor',
  2 => 'Agencia de Cobros',
  3 => 'Alistamiento Mal Realizado',
  4 => 'Amenaza Demanda Actividad Promocional',
  5 => 'Amenaza Demanda Compañía',
  6 => 'Amenaza Demanda Producto',
  7 => 'Arrugado',
  8 => 'Asesoría para Usar el Portal',
  9 => 'Asignación de Plan Itinerario',
  10 => 'Asistió',
  11 => 'Autoriza Tratamiento de Datos',
  12 => 'Baboso',
  13 => 'Billeteros',
  14 => 'Bloom',
  15 => 'Calidad del Premio',
  16 => 'Call Center y Otros',
  17 => 'Cambio',
  18 => 'Cambio de Dirección',
  19 => 'Cancelación/Modificación',
  20 => 'Cantidad de Vendedores',
  21 => 'Carro Heladero',
  22 => 'Código',
  23 => 'Color',
  24 => 'Compactado y Aglomerado',
  25 => 'Condición de Pago',
  26 => 'Condiciones para Ser Cliente',
  27 => 'Congelador Falla Funcional',
  28 => 'Congelador Falla No Funcional',
  29 => 'Contacto No Efectivo',
  30 => 'Contrato de Empresaria',
  31 => 'Cristalizado',
  32 => 'Cuchara o Pitillo',
  33 => 'Deforme',
  34 => 'Demora en la Entrega',
  35 => 'Derretido',
  36 => 'Digitado No Facturado',
  37 => 'Disminución de Cantidad en Producto',
  38 => 'Easy Open',
  39 => 'Elemento Promocional',
  40 => 'Empaque Sellado Sin Producto',
  41 => 'En Corrugado, Fardo o Bolsa',
  42 => 'En Unidad de Consumo',
  43 => 'En Unidad de Venta',
  44 => 'Entrega',
  45 => 'Entrega de Premios',
  46 => 'Entrega en Dirección Incorrecta',
  47 => 'Entregador',
  48 => 'Entregador no Entregó el Pedido',
  49 => 'Envio de Referencia Equivocada',
  50 => 'Error en la Toma de Pedido',
  51 => 'Error en la Toma de Pedido Televendedor',
  52 => 'Errores de Marcación',
  53 => 'Esquema de Atención',
  54 => 'Exhibición del Punto de Venta',
  55 => 'Experiencias',
  56 => 'Factura Original no Entregada',
  57 => 'Facturado No Despachado',
  58 => 'Falsificación',
  59 => 'Faltante de Producto por Agotado',
  60 => 'Fecha de Vencimiento y Lotes Ilegibles, Errados o Ausentes',
  61 => 'Ficha Técnica',
  62 => 'Foil',
  63 => 'Frecuencia de Visita',
  64 => 'Funcionalidad del Empaque',
  65 => 'Garantía del Premio',
  66 => 'General',
  67 => 'Grasa Lateral',
  68 => 'Inconsistencia en Precio/Pagos o Abonos',
  69 => 'Inflado',
  70 => 'Información Nutricional/Ingredientes',
  71 => 'Información Nutricional/Salud',
  72 => 'Ingreso Página Web',
  73 => 'Inscripción',
  74 => 'Inscrito',
  75 => 'Insuficiente, Ausente o Excesivo',
  76 => 'Interesado',
  77 => 'Inventario No Realizado',
  78 => 'Lechoso',
  79 => 'Líder Ventas por Catálogo',
  80 => 'Llegó Tarde',
  81 => 'Lo Facturado No es lo Entregado',
  82 => 'Mal Estado del Empaque',
  83 => 'Mala Presentación del Producto',
  84 => 'Manejo de Producto',
  85 => 'Mantenimiento Mal Realizado',
  86 => 'Mantenimiento No Realizado',
  87 => 'Máquinas Dispensadoras',
  88 => 'Mecánica',
  89 => 'Mecánica de la Campaña/Promoción',
  90 => 'Mercaderismo/Impulso',
  91 => 'Montaje de Nuevos Negocios',
  92 => 'Movilización No Realizada',
  93 => 'Neveras',
  94 => 'No Atribuible a Compañía',
  95 => 'No Han Recogido',
  96 => 'No Llegó',
  97 => 'No Llegó la Promoción',
  98 => 'No llegó/No Está en el Sistema',
  99 => 'Objetos Extraño',
  100 => 'Objetos Extraño Metálico',
  101 => 'Ofrece Nuevos Servicios',
  102 => 'Olor',
  103 => 'Otros',
  104 => 'Oxidado',
  105 => 'Pedido no Tomado por Políticas Comerciales',
  106 => 'Pérdida de Vacío',
  107 => 'Personal Call Center',
  108 => 'Personal de Activos',
  109 => 'Personal de la Compañía',
  110 => 'Personal Técnico',
  111 => 'Peso Inferior al Declarado',
  112 => 'Premia tu Cliente',
  113 => 'Premio',
  114 => 'Presencia de Moho/Hongos',
  115 => 'Problemas con su Usuario',
  116 => 'Problemas de Visualización/No Carga la Página',
  117 => 'Producto Partido',
  118 => 'Producto Próximo a Vencer',
  119 => 'Producto Vencido',
  120 => 'Publicidad Engañosa',
  121 => 'Quebrado',
  122 => 'Recogida',
  123 => 'Redención de Premios',
  124 => 'Redes Sociales',
  125 => 'Referencias Restringidas',
  126 => 'Registro Sanitario',
  127 => 'Rendimiento',
  128 => 'Sabor',
  129 => 'Salud Afectada',
  130 => 'Sellado',
  131 => 'Sellos',
  132 => 'Solicitudes del Cliente',
  133 => 'Textura',
  134 => 'Toma de Pedido Devolución',
  135 => 'Toma de Pedido ERP',
  136 => 'Toma de Pedido Manual',
  137 => 'Usuario y Contraseña Para Ingresar',
  138 => 'Vendedor/Líder/Gerente',
  139 => 'Venta Previa a Temporada',
  140 => 'Ventana de Innovación',
  141 => 'Verde',
  142 => 'Verifica Estatus Premio',
  143 => 'Visualización/Cargue de Página/Navegación',
  144 => 'Retraso o Ausencia de respuesta',
  145 => 'Ofrece nuevos productos y publicidad',
  146 => 'Ofrece nuevas Máquinas',
  147 => 'Ofrece procesos logísticos y de Tecnologia',
  148 => 'Nuevo Nit',
  149 => 'Mama Empresaria',
  150 => 'Medios de Pago / Devolución',
  151 => 'Anchetas',
  152 => 'Medios de Pago / Transferencia',
  153 => 'Cancelación/ Modificación',
  154 => 'Cancelación/modificación pedido vendedor',
  155 => 'Cliente bloqueado o inactivo',
  156 => 'Compañía',
  157 => 'Completar/corregir información',
  158 => 'Corrugada dañada',
  159 => 'Creación de nuevo punto de venta',
  160 => 'Degustaciones',
  161 => 'Demanda Marca',
  162 => 'Donaciones',
  163 => 'Empaque con impresion defectuosa',
  164 => 'Empaque o foil roto o perforado',
  165 => 'Entregado incompleto',
  166 => 'Error en la toma de pedido manual',
  167 => 'Etiqueta dañada/rota/perforada',
  168 => 'Falsificacion de producto y empaque',
  169 => 'Faltan referencias en el portafolio',
  170 => 'Foil poroso',
  171 => 'Garantía de premios',
  172 => 'Impulsadora/mercaderista',
  173 => 'Incumplimiento en promesa de atencion',
  174 => 'Insatisfacción con el producto sustituto/reemplazado',
  175 => 'Mal corte',
  176 => 'Salud Afectada por Elemento Promocional',
  177 => 'Mecanica de la campaña/promocion',
  178 => 'Navegación en el portal',
  179 => 'No contactado/No hay respuesta',
  180 => 'No entregado problemas de pago',
  181 => 'No está en el sistema',
  182 => 'Pagina web-acceso',
  183 => 'Paquete pegado al fardo',
  184 => 'Pedido Manual no digitado',
  185 => 'Pedido visado',
  186 => 'Pelones',
  187 => 'Premios/ganadores/valor comercial',
  188 => 'Problemas compañia o fuerza mayor',
  189 => 'Producto',
  190 => 'Producto con obsequio',
  191 => 'Producto contaminado',
  192 => 'Producto mal empacado/al reves',
  193 => 'Producto sucio / chorreado',
  194 => 'Rayas',
  195 => 'Reactivación',
  196 => 'Regional/sede',
  197 => 'Registro',
  198 => 'Reventado',
  199 => 'Rotulado/Empaque errado',
  200 => 'Sin etiqueta',
  201 => 'Tapa apretada',
  202 => 'Tapa floja',
  203 => 'Televendedor no informo promocion',
  204 => 'Tiempos de coccion',
  205 => 'Toma Pedido Moto Carguero',
  206 => 'Vendedor no informó promoción',
  207 => 'Vendedor/gerente/lider',
  208 => 'Visado inconsistente',
  209 => 'No reportado en factura', 
  210 => 'Reportado en factura', 
  211 => 'Objetos Extraños Que Afectan la Salud',
  212 => 'Salud Afectada por Consumo de Producto',
  213 => 'Concurso Promocional Lider',
  214 => 'Sin referir web',
  215 => 'Adherido al papel/descascarado',
  216 => 'Ausencia de foil',
  217 => 'Calidad/Garantia del premio entregado',
  218 => 'Amenaza a la seguridad de la compañía',
  219 => 'Amenaza Demanda',
);

?>
<?php
 // created: 2017-02-04 04:00:55

$app_list_strings['sasanovd_yearcampaign_c_list']=array (
  '' => '',
  '2017' => '2017',
  '2018' => '2018',
  '2019' => '2019',
  '2020' => '2020',
  '2021' => '2021',
  '2022' => '2022',
  '2023' => '2023',
  '2024' => '2024',
  '2025' => '2025',
  '2026' => '2026',
  '2027' => '2027',
  '2028' => '2028',
  '2029' => '2029',
  '2030' => '2030',
  '2031' => '2031',
  '2032' => '2032',
  '2033' => '2033',
  '2034' => '2034',
  '2055' => '2035',
  '2036' => '2036',
  '2037' => '2037',
  '2038' => '2038',
  '2039' => '2039',
  '2040' => '2040',
);

?>
<?php
 // created: 2017-01-26 16:45:15

$app_list_strings['sasanovd_campaign_c_list']=array (
  '' => '',
  'C01' => 'C01',
  'C02' => 'C02',
  'C03' => 'C03',
  'C04' => 'C04',
  'C05' => 'C05',
  'C06' => 'C06',
  'C07' => 'C07',
  'C08' => 'C08',
  'C09' => 'C09',
  'C10' => 'C10',
  'C11' => 'C11',
  'C12' => 'C12',
  'C13' => 'C13',
  'C14' => 'C14',
  'C15' => 'C15',
  'C16' => 'C16',
  'C17' => 'C17',
  'C18' => 'C18',
);

?>
<?php
 // created: 2017-02-10 21:32:18

$app_list_strings['sasanovd_nrovecmereportdev_c_list']=array (
  '' => '',
  'Es la primera o segunda vez' => 'Es la primera o segunda vez',
  'Es la tercera vez o mas' => 'Es la tercera vez o más',
);

?>
<?php
 // created: 2017-02-10 21:32:18

$app_list_strings['sasa_sino_list']=array (
  '' => '',
  'Si' => 'Si',
  'No' => 'No',
);
?>
<?php
 // created: 2017-02-04 01:52:47

$app_list_strings['sasanovd_mediomerealizoped_c_list']=array (
  '' => '',
  'Scad' => 'Scad',
  'Web' => 'Web',
);

?>
<?php
 // created: 2017-02-04 01:55:21

$app_list_strings['sasanovd_nvmerepinoconprod_c_list']=array (
  '' => '',
  'Primera' => 'Primera',
  'Segunda' => 'Segunda',
  'Tercera' => 'Tercera',
);

?>
<?php
 // created: 2017-02-04 01:54:47

$app_list_strings['sasanovd_tipopedidopartido_c_list']=array (
  '' => '',
  'Caja' => 'Caja',
  'Alpina' => 'Alpina',
  'Carnicos' => 'Carnicos',
  'Helados' => 'Helados',
);

?>
<?php
 // created: 2016-09-29 23:12:23

$app_list_strings['sasa_ctrl_sec_c_list']=array (
  1 => '1',
  2 => '2',
  3 => '3',
  4 => '4',
  5 => '5',
  6 => '6',
  7 => '7',
  8 => '8',
  9 => '9',
  10 => '10',
  11 => '11',
  12 => '12',
  13 => '13',
  14 => '14',
  15 => '15',
  16 => '16',
  17 => '17',
  18 => '18',
  19 => '19',
  20 => '20',
  21 => '21',
  22 => '22',
  23 => '23',
  24 => '24',
  25 => '25',
  26 => '26',
  27 => '27',
  28 => '28',
  29 => '29',
  30 => '30',
  31 => '31',
  32 => '32',
  33 => '33',
  34 => '34',
  35 => '35',
  36 => '36',
  37 => '37',
  38 => '38',
  39 => '39',
  40 => '40',
  41 => '41',
  42 => '42',
  43 => '43',
  44 => '44',
  45 => '45',
  46 => '46',
  47 => '47',
  48 => '48',
  49 => '49',
  50 => '50',
  51 => '51',
  52 => '52',
  53 => '53',
  54 => '54',
  55 => '55',
  56 => '56',
  57 => '57',
  58 => '58',
  59 => '59',
  60 => '60',
  61 => '61',
  62 => '62',
  63 => '63',
  64 => '64',
  65 => '65',
  66 => '66',
  67 => '67',
  68 => '68',
  69 => '69',
  70 => '70',
  71 => '71',
  72 => '72',
  73 => '73',
  74 => '74',
  75 => '75',
  76 => '76',
  77 => '77',
  78 => '78',
  79 => '79',
  80 => '80',
  81 => '81',
  82 => '82',
  83 => '83',
  84 => '84',
  85 => '85',
  86 => '86',
  87 => '87',
  88 => '88',
  89 => '89',
  90 => '90',
  91 => '91',
  92 => '92',
  93 => '93',
  94 => '94',
  95 => '95',
  96 => '96',
  97 => '97',
  98 => '98',
  99 => '99',
);

?>
<?php
 // created: 2016-09-29 23:12:23

$app_list_strings['sasalr_companiaactivo_c_list']=array (
  '' => '',
  'Meals' => 'Meals',
  'Colcafe' => 'Colcafé',
  'Alimentos Carnicos' => 'Alimentos Cárnicos',
  'Alpina' => 'Alpina',
  'Nacional de Chocolates' => 'Nacional de Chocolates',
);


$app_list_strings['moduleList']['s123_Indicadores'] = 'Indicadores de Oportunidad';
$app_list_strings['moduleList']['s123_Detalle_indicadores'] = 'Indicadores detallado';
$app_list_strings['moduleListSingular']['s123_Indicadores'] = 'Indicador de Oportunidad';
$app_list_strings['moduleListSingular']['s123_Detalle_indicadores'] = 'Indicador detallado';
 
 
 
 
 
$app_list_strings['syno_roles_list']=array (
  'fb3f9e42-e16f-11e6-ac35-06eb7fcc0457' => 'Consultor CRM',
  '60609594-6e28-11e6-8e0c-027a430c0995' => 'Coordinadores CIC',
  '842544ec-5f01-11e6-82bb-027a430c0995' => 'Customer Self-Service Portal Role',
  '31ca9ec3-e8a1-b926-3198-577467c957f6' => 'Customer Support Administrator',
  '493e649e-efde-11e6-ac85-02729de96d09' => 'LR Agentes',
  'efbb520c-76c1-ae63-c19f-577467d56c28' => 'Marketing Administrator',
  '80b6443a-8762-11e6-9289-02a6691319f3' => 'NO Admin CIC',
  'bc0fe950-858c-11e6-b331-060b37ffb723' => 'NO Red de Servicios',
  '572e0f92-8679-11e6-ace4-06d48441b777' => 'NO VP Agentes',
  '46e59ce0-8679-11e6-8448-06d48441b777' => 'NO VP Backoffice',
  '1c471e1c-8595-11e6-b400-027a430c0995' => 'NO VP Coordinador Lider Call Center',
  '2e73f0fc-d42c-11e6-9a88-02b215474f0b' => 'NO VP Monitor Calidad Call Center',
  'ff008b3e-8591-11e6-9fff-06d48441b777' => 'NO VP Red de Servicios Avanzado',
  '2c1e6c6a-8715-11e6-83ab-06d48441b777' => 'PZ Admin CIC',
  '1e91078a-8713-11e6-ab23-027a430c0995' => 'PZ Red de Servicios',
  '6e3e9b8e-6e28-11e6-bcf1-027a430c0995' => 'Rol 3',
  '75b4a66a-6e28-11e6-b0b9-027a430c0995' => 'Rol 4',
  '676cc204-6e28-11e6-8dcb-027a430c0995' => 'Rol base (NO BORRAR)',
  '1e29dcd2-da82-11e6-b7d1-02729de96d09' => 'Rol de Tareas',
  'b4d49231-4904-df0f-d2d1-577467e1e14b' => 'Sales Administrator',
  '03052a8c-89b6-11e6-9881-06b20b8677ed' => 'SN Admin CIC',
  'dfc202f6-89b1-11e6-af6c-06d48441b777' => 'SN Agentes',
  'c72ddfbc-9a32-11e6-9ddb-02a6691319f3' => 'SN Backoffice',
  '66b33dac-89b2-11e6-8910-06b20b8677ed' => 'SN Red de Servicios',
  '41d97258-89b2-11e6-b73d-060b37ffb723' => 'SN Red de Servicios Avanzado',
  '16fddb0b-4e77-9716-50b8-57746786eff2' => 'Tracker',
);



$app_list_strings['sasa_justificacion_recalc_c_list']=
array ( 
	'1' => 'Incapacidad médica',
	'2' => 'Licencia/Vacaciones',
	'3' => 'Retiro de empleado',
);



$app_list_strings['sasa_tipo_indicador_c_list']=array (
	'1' => 'Casos pendientes al inicios del mes',
	'2' => 'Casos creados durante el mes',
	'3' => 'Casos Totales del mes',
	'4' => 'Casos cerrados a tiempo',
	'5' => 'Casos cerrados fuera de tiempo',
	'6' => 'Casos no vencidos al final del mes',
	'7' => 'Casos vencidos al final del mes',
);



$app_list_strings['sasa_month_c_list']=array (
	'1' => 'Enero',
	'2' => 'Febrero',
	'3' => 'Marzo',
	'4' => 'Abril',
	'5' => 'Mayo',
	'6' => 'Junio',
	'7' => 'Julio',
	'8' => 'Ago',
	'9' => 'Septiembre',
	'10' => 'Octubre',
	'11' => 'Noviembre',
	'12' => 'Diciembre',
);


$app_list_strings['sasa_tipo_ind_c_list']=array ( 
	'CST' => 'CST',
	'CSFT' => 'CSFT',
	'CVMS' => 'CV',
	'CNVMS' => 'CNV',
);
?>
